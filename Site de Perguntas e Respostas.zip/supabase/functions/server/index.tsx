import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

app.use("*", logger(console.log));
app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
}));

app.get("/make-server-bfdc3feb/health", (c) => c.json({ status: "ok" }));

// AI explanation endpoint
app.post("/make-server-bfdc3feb/ai-explain", async (c) => {
  try {
    const body = await c.req.json();
    const { question, correctAnswer, userAnswer, subject, topic, explanation } = body;

    const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
    if (!apiKey) {
      return c.json({ explanation: generateFallback(correctAnswer, userAnswer, subject, topic, explanation) });
    }

    const prompt = `Você é um professor especialista em vestibulares de alta complexidade, com foco no ITA (Instituto Tecnológico de Aeronáutica).

Um aluno respondeu incorretamente uma questão de ${subject} sobre o tópico "${topic}".

Questão: ${question}

Resposta correta: ${correctAnswer}
Resposta do aluno: ${userAnswer}

Explicação base: ${explanation}

Forneça uma correção pedagógica completa em português com:
1. **Por que você errou**: explique o erro conceitual ou de raciocínio de forma direta
2. **Resolução passo a passo**: mostre como chegar à resposta correta de forma didática
3. **Dica para a próxima vez**: um conselho prático e memorável para não cometer o mesmo erro

Use markdown simples. Seja preciso, didático e encorajador. Máximo 300 palavras.`;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 500,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      return c.json({ explanation: generateFallback(correctAnswer, userAnswer, subject, topic, explanation) });
    }

    const data = await res.json();
    const text = data.content?.[0]?.text || generateFallback(correctAnswer, userAnswer, subject, topic, explanation);
    return c.json({ explanation: text });
  } catch (e) {
    console.error(e);
    return c.json({ explanation: "Não foi possível gerar a correção inteligente. Consulte a explicação acima." });
  }
});

function generateFallback(correctAnswer: string, userAnswer: string, subject: string, topic: string, explanation: string): string {
  return `**Por que você errou:**\nVocê marcou **${userAnswer}**, mas a correta é **${correctAnswer}**.

**Resolução:**\n${explanation}

**Dica para a próxima vez:**\nReforce seus estudos no tópico **${topic}** de **${subject}**. Revise os conceitos fundamentais e pratique questões semelhantes.`;
}

Deno.serve(app.fetch);
