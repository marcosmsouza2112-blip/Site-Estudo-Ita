import { useState, useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import type { User } from "@supabase/supabase-js";
import questions, { SUBJECTS, YEARS, type Subject } from "../data/questions";
import { saveSimulado, getSimulados, deleteSimulado, saveAnswer, type SimuladoState } from "../lib/store";
import QuestionCard from "../components/QuestionCard";

type Props = { user: User };

function formatTime(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

export function SimuladoProva({ user }: Props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [sim, setSim] = useState<SimuladoState | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [paused, setPaused] = useState(false);
  const [answered, setAnswered] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    getSimulados(user.id).then((sims) => {
      const found = sims.find((s) => s.id === id);
      if (!found) { navigate("/simulado"); return; }
      setSim(found);
      setCurrentIdx(Object.keys(found.answers).length);
      setElapsed(found.timeElapsedSeconds);
    });
  }, [id, user.id, navigate]);

  useEffect(() => {
    if (!sim || paused) { if (timerRef.current) clearInterval(timerRef.current); return; }
    timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [sim, paused]);

  async function handlePause() {
    setPaused(true);
    if (!sim) return;
    const updated = { ...sim, timeElapsedSeconds: elapsed, pausedAt: new Date().toISOString() };
    await saveSimulado(updated);
    navigate("/simulado");
  }

  async function handleAnswer(answer: string, correct: boolean) {
    if (!sim) return;
    const q = questions.find((x) => x.id === sim.questions[currentIdx]);
    if (!q) return;

    const updatedAnswers = { ...sim.answers, [q.id]: answer };
    const updatedSim = { ...sim, answers: updatedAnswers, timeElapsedSeconds: elapsed };

    if (Object.keys(updatedAnswers).length >= sim.questions.length) {
      updatedSim.completedAt = new Date().toISOString();
    }

    await saveSimulado(updatedSim);
    await saveAnswer(user.id, {
      questionId: q.id, userAnswer: answer, correct,
      subject: q.subject, year: q.year, difficulty: q.difficulty, topic: q.topic,
    });

    setSim(updatedSim);
    setAnswered(true);
  }

  function nextQuestion() {
    if (!sim) return;
    setAnswered(false);
    if (currentIdx + 1 >= sim.questions.length) {
      navigate("/desempenho");
    } else {
      setCurrentIdx((i) => i + 1);
    }
  }

  if (!sim) return (
    <div className="flex items-center justify-center h-96 opacity-40 text-sm">Carregando simulado...</div>
  );

  const q = questions.find((x) => x.id === sim.questions[currentIdx]);
  if (!q) return null;

  if (sim.completedAt) {
    const correct = sim.questions.filter((qid) => {
      const quest = questions.find((x) => x.id === qid);
      return quest && sim.answers[qid] === quest.answer;
    }).length;
    return (
      <div className="p-6 max-w-lg mx-auto text-center pt-16">
        <div className="text-5xl mb-4">🏁</div>
        <div className="text-2xl font-black mb-4" style={{ color: "#c8b97a" }}>Simulado Finalizado!</div>
        <div className="text-4xl font-black">{Math.round((correct / sim.questions.length) * 100)}%</div>
        <div className="text-sm opacity-50 mt-1 mb-2">{correct}/{sim.questions.length} acertos</div>
        <div className="text-sm opacity-40 mb-8">Tempo total: {formatTime(elapsed)}</div>
        <button onClick={() => navigate("/desempenho")} className="px-6 py-3 rounded-xl font-bold text-sm" style={{ background: "#c8b97a", color: "#0a0c14" }}>
          Ver Desempenho →
        </button>
      </div>
    );
  }

  return (
    <div className="p-4">
      {/* Timer bar */}
      <div className="max-w-2xl mx-auto mb-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-lg font-mono font-black" style={{ color: "#c8b97a" }}>{formatTime(elapsed)}</div>
          <button
            onClick={handlePause}
            className="text-xs px-3 py-1.5 rounded-lg border border-white/10 opacity-50 hover:opacity-100 transition"
          >
            ⏸ Pausar
          </button>
        </div>
        <div className="text-xs opacity-40">
          {currentIdx + 1}/{sim.questions.length} · {sim.name}
        </div>
      </div>

      {/* Progress */}
      <div className="max-w-2xl mx-auto mb-5">
        <div className="h-1 rounded-full bg-white/8">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${(currentIdx / sim.questions.length) * 100}%`, background: "#c8b97a" }}
          />
        </div>
      </div>

      <QuestionCard
        question={q}
        onAnswer={handleAnswer}
        showIndex={`Q${currentIdx + 1}`}
        mode="simulado"
      />

      {answered && (
        <div className="max-w-2xl mx-auto mt-4">
          <button
            onClick={nextQuestion}
            className="w-full py-3 rounded-xl text-sm font-bold tracking-wider uppercase border border-white/10 opacity-60 hover:opacity-100 transition-opacity"
          >
            {currentIdx + 1 >= sim.questions.length ? "Finalizar Simulado 🏁" : "Próxima Questão →"}
          </button>
        </div>
      )}
    </div>
  );
}

export default function Simulado({ user }: Props) {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<"list" | "new">("list");
  const [simName, setSimName] = useState("Simulado ITA");
  const [selectedSubjects, setSelectedSubjects] = useState<Subject[]>([]);
  const [selectedYears, setSelectedYears] = useState<number[]>([]);
  const [totalQuestions, setTotalQuestions] = useState(30);
  const [simulados, setSimulados] = useState<SimuladoState[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getSimulados(user.id).then((sims) => { setSimulados(sims); setLoading(false); });
  }, [user.id]);

  function toggleItem<T>(arr: T[], item: T, set: (v: T[]) => void) {
    set(arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item]);
  }

  async function createSimulado() {
    let pool = questions.filter((q) => {
      const subjOk = selectedSubjects.length === 0 || selectedSubjects.includes(q.subject);
      const yearOk = selectedYears.length === 0 || selectedYears.includes(q.year);
      return subjOk && yearOk;
    });
    pool = pool.sort(() => Math.random() - 0.5).slice(0, totalQuestions);

    const sim: SimuladoState = {
      id: Date.now().toString(),
      userId: user.id,
      name: simName,
      questions: pool.map((q) => q.id),
      answers: {},
      currentIndex: 0,
      startedAt: new Date().toISOString(),
      timeElapsedSeconds: 0,
      subjects: selectedSubjects,
      years: selectedYears,
    };

    await saveSimulado(sim);
    navigate(`/simulado/prova/${sim.id}`);
  }

  async function handleDelete(simId: string) {
    await deleteSimulado(user.id, simId);
    setSimulados((s) => s.filter((x) => x.id !== simId));
  }

  const SUBJECT_COLORS: Record<string, string> = {
    blue: "#60a5fa", purple: "#c084fc", green: "#4ade80", amber: "#fbbf24"
  };

  if (phase === "new") {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <button onClick={() => setPhase("list")} className="text-xs opacity-40 mb-6 hover:opacity-70 transition">← Voltar</button>
        <div className="mb-8">
          <div className="text-xs tracking-[0.3em] uppercase opacity-30 mb-1">Novo</div>
          <h1 className="text-2xl font-bold" style={{ color: "#c8b97a" }}>Criar Simulado</h1>
        </div>

        <div className="space-y-6">
          <div>
            <label className="text-xs uppercase tracking-widest opacity-40 block mb-2">Nome do Simulado</label>
            <input
              value={simName}
              onChange={(e) => setSimName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg text-sm bg-white/5 border border-white/10 text-white focus:outline-none focus:border-amber-400/40"
            />
          </div>

          <div>
            <label className="text-xs uppercase tracking-widest opacity-40 block mb-3">Matérias</label>
            <div className="grid grid-cols-2 gap-2">
              {SUBJECTS.map((s) => {
                const active = selectedSubjects.includes(s.id);
                return (
                  <button
                    key={s.id}
                    onClick={() => toggleItem(selectedSubjects, s.id, setSelectedSubjects)}
                    className="rounded-xl p-4 border text-left transition-all"
                    style={active
                      ? { background: `${SUBJECT_COLORS[s.color]}15`, border: `1px solid ${SUBJECT_COLORS[s.color]}50` }
                      : { background: "#0d0f1a", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <span style={{ color: active ? SUBJECT_COLORS[s.color] : undefined }}>{s.icon}</span>
                    <div className="text-sm font-medium mt-1">{s.label}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="text-xs uppercase tracking-widest opacity-40 block mb-3">Anos</label>
            <div className="flex flex-wrap gap-2">
              {YEARS.map((y) => {
                const active = selectedYears.includes(y);
                return (
                  <button
                    key={y}
                    onClick={() => toggleItem(selectedYears, y, setSelectedYears)}
                    className="px-4 py-2 rounded-lg text-sm border transition-all"
                    style={active
                      ? { background: "rgba(200,185,122,0.15)", border: "1px solid rgba(200,185,122,0.4)", color: "#c8b97a", fontWeight: 700 }
                      : { background: "#0d0f1a", border: "1px solid rgba(255,255,255,0.08)", opacity: 0.5 }}
                  >
                    {y}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs uppercase tracking-widest opacity-40">Total de Questões</label>
              <span className="text-sm font-bold" style={{ color: "#c8b97a" }}>{totalQuestions}</span>
            </div>
            <input
              type="range" min={5} max={60} step={5} value={totalQuestions}
              onChange={(e) => setTotalQuestions(+e.target.value)}
              className="w-full accent-amber-400"
            />
          </div>

          <button
            onClick={createSimulado}
            className="w-full py-4 rounded-xl font-black text-sm uppercase tracking-wider"
            style={{ background: "#c8b97a", color: "#0a0c14" }}
          >
            Iniciar Simulado →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="text-xs tracking-[0.3em] uppercase opacity-30 mb-1">Modo</div>
          <h1 className="text-2xl font-bold" style={{ color: "#c8b97a" }}>Simulados</h1>
        </div>
        <button
          onClick={() => setPhase("new")}
          className="px-4 py-2 rounded-xl text-sm font-bold"
          style={{ background: "#c8b97a", color: "#0a0c14" }}
        >
          + Novo
        </button>
      </div>

      {loading && <div className="text-sm opacity-40">Carregando...</div>}

      {!loading && simulados.length === 0 && (
        <div className="text-center py-16">
          <div className="text-4xl mb-4 opacity-30">⏱</div>
          <div className="text-sm opacity-40">Nenhum simulado ainda.</div>
          <div className="text-xs opacity-30 mt-1">Crie um simulado para começar.</div>
        </div>
      )}

      <div className="space-y-3">
        {simulados.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()).map((s) => {
          const answered = Object.keys(s.answers).length;
          const pct = Math.round((answered / s.questions.length) * 100);
          const completed = !!s.completedAt;
          return (
            <div key={s.id} className="rounded-xl p-5 border border-white/8" style={{ background: "#0d0f1a" }}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="font-bold text-sm mb-0.5">{s.name}</div>
                  <div className="text-xs opacity-40">
                    {new Date(s.startedAt).toLocaleDateString("pt-BR")} · {s.questions.length} questões
                  </div>
                </div>
                <span
                  className="text-xs px-2 py-1 rounded-full font-bold"
                  style={completed
                    ? { background: "rgba(74,222,128,0.1)", color: "#4ade80" }
                    : { background: "rgba(200,185,122,0.1)", color: "#c8b97a" }}
                >
                  {completed ? "Concluído" : `${pct}%`}
                </span>
              </div>

              <div className="h-1 rounded-full bg-white/8 mb-4">
                <div
                  className="h-full rounded-full"
                  style={{ width: `${pct}%`, background: completed ? "#4ade80" : "#c8b97a" }}
                />
              </div>

              <div className="flex gap-2">
                {!completed && (
                  <button
                    onClick={() => navigate(`/simulado/prova/${s.id}`)}
                    className="flex-1 py-2 rounded-lg text-xs font-bold"
                    style={{ background: "rgba(200,185,122,0.15)", color: "#c8b97a" }}
                  >
                    Continuar →
                  </button>
                )}
                <button
                  onClick={() => handleDelete(s.id)}
                  className="py-2 px-3 rounded-lg text-xs border border-white/8 opacity-40 hover:opacity-80 transition"
                >
                  Excluir
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
