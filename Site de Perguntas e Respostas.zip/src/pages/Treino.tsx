import { useState } from "react";
import type { User } from "@supabase/supabase-js";
import { SUBJECTS, YEARS, type Subject, type Difficulty } from "../data/questions";
import questions from "../data/questions";
import QuestionCard from "../components/QuestionCard";
import { saveAnswer } from "../lib/store";

type Props = { user: User };
type Phase = "config" | "quiz" | "done";

const DIFFICULTIES: { id: Difficulty; label: string }[] = [
  { id: "facil", label: "Fácil" },
  { id: "medio", label: "Médio" },
  { id: "dificil", label: "Difícil" },
];

const SUBJECT_COLORS: Record<string, string> = {
  blue: "#60a5fa", purple: "#c084fc", green: "#4ade80", amber: "#fbbf24"
};

export default function Treino({ user }: Props) {
  const [phase, setPhase] = useState<Phase>("config");
  const [selectedSubjects, setSelectedSubjects] = useState<Subject[]>([]);
  const [selectedYears, setSelectedYears] = useState<number[]>([]);
  const [selectedDiffs, setSelectedDiffs] = useState<Difficulty[]>(["facil", "medio", "dificil"]);
  const [subjectCounts, setSubjectCounts] = useState<Record<Subject, number>>({
    matematica: 5, fisica: 5, quimica: 5, ingles: 5,
  });
  const [quizQuestions, setQuizQuestions] = useState(questions.slice(0, 0));
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  function toggleItem<T>(arr: T[], item: T, set: (v: T[]) => void) {
    set(arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item]);
  }

  function startQuiz() {
    let pool = questions.filter((q) => {
      const subjectOk = selectedSubjects.length === 0 || selectedSubjects.includes(q.subject);
      const yearOk = selectedYears.length === 0 || selectedYears.includes(q.year);
      const diffOk = selectedDiffs.length === 0 || selectedDiffs.includes(q.difficulty);
      return subjectOk && yearOk && diffOk;
    });

    if (selectedSubjects.length > 0) {
      const bySubject: typeof pool = [];
      selectedSubjects.forEach((s) => {
        const sub = pool.filter((q) => q.subject === s);
        const shuffled = sub.sort(() => Math.random() - 0.5).slice(0, subjectCounts[s]);
        bySubject.push(...shuffled);
      });
      pool = bySubject.sort(() => Math.random() - 0.5);
    } else {
      pool = pool.sort(() => Math.random() - 0.5).slice(0, 20);
    }

    setQuizQuestions(pool);
    setCurrentIdx(0);
    setScore({ correct: 0, total: 0 });
    setPhase("quiz");
  }

  async function handleAnswer(answer: string, correct: boolean) {
    const q = quizQuestions[currentIdx];
    await saveAnswer(user.id, {
      questionId: q.id,
      userAnswer: answer,
      correct,
      subject: q.subject,
      year: q.year,
      difficulty: q.difficulty,
      topic: q.topic,
    });
    setScore((s) => ({ correct: s.correct + (correct ? 1 : 0), total: s.total + 1 }));
  }

  function nextQuestion() {
    if (currentIdx + 1 >= quizQuestions.length) setPhase("done");
    else setCurrentIdx((i) => i + 1);
  }

  if (phase === "done") {
    const rate = Math.round((score.correct / score.total) * 100);
    return (
      <div className="p-6 max-w-lg mx-auto text-center pt-16">
        <div className="text-6xl mb-4">{rate >= 70 ? "🎯" : "📚"}</div>
        <div className="text-2xl font-black mb-2" style={{ color: "#c8b97a" }}>Treino Concluído!</div>
        <div className="text-4xl font-black mt-4 mb-1">{rate}%</div>
        <div className="text-sm opacity-50 mb-8">{score.correct} de {score.total} acertos</div>
        <button
          onClick={() => setPhase("config")}
          className="px-6 py-3 rounded-xl font-bold text-sm"
          style={{ background: "#c8b97a", color: "#0a0c14" }}
        >
          Novo Treino
        </button>
      </div>
    );
  }

  if (phase === "quiz") {
    const q = quizQuestions[currentIdx];
    const isLast = currentIdx === quizQuestions.length - 1;
    return (
      <div className="p-6">
        {/* Progress */}
        <div className="max-w-2xl mx-auto mb-6">
          <div className="flex items-center justify-between mb-2 text-xs opacity-40">
            <span>Questão {currentIdx + 1} de {quizQuestions.length}</span>
            <span>{score.correct} acertos até agora</span>
          </div>
          <div className="h-1 rounded-full bg-white/8">
            <div
              className="h-full rounded-full transition-all"
              style={{ width: `${((currentIdx) / quizQuestions.length) * 100}%`, background: "#c8b97a" }}
            />
          </div>
        </div>

        <QuestionCard
          question={q}
          onAnswer={handleAnswer}
          showIndex={`Q${currentIdx + 1}`}
          mode="treino"
        />

        <div className="max-w-2xl mx-auto mt-4">
          <button
            onClick={nextQuestion}
            className="w-full py-3 rounded-xl text-sm font-bold tracking-wider uppercase border border-white/10 opacity-50 hover:opacity-100 transition-opacity"
          >
            {isLast ? "Finalizar Treino" : "Próxima Questão →"}
          </button>
        </div>
      </div>
    );
  }

  // Config phase
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-8">
        <div className="text-xs tracking-[0.3em] uppercase opacity-30 mb-1">Configurar</div>
        <h1 className="text-2xl font-bold" style={{ color: "#c8b97a" }}>Modo Treino</h1>
      </div>

      {/* Subjects */}
      <section className="mb-8">
        <div className="text-xs tracking-widest uppercase opacity-40 mb-3">Matérias</div>
        <div className="grid grid-cols-2 gap-2">
          {SUBJECTS.map((s) => {
            const active = selectedSubjects.includes(s.id);
            return (
              <button
                key={s.id}
                onClick={() => toggleItem(selectedSubjects, s.id, setSelectedSubjects)}
                className="rounded-xl p-4 border transition-all text-left"
                style={active
                  ? { background: `${SUBJECT_COLORS[s.color]}15`, border: `1px solid ${SUBJECT_COLORS[s.color]}50` }
                  : { background: "#0d0f1a", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <div className="text-xl mb-1" style={{ color: active ? SUBJECT_COLORS[s.color] : undefined }}>{s.icon}</div>
                <div className="text-sm font-medium">{s.label}</div>
                {active && (
                  <div className="mt-2">
                    <div className="text-xs opacity-40 mb-1">Qtd. de questões: {subjectCounts[s.id]}</div>
                    <input
                      type="range" min={1} max={10} value={subjectCounts[s.id]}
                      onClick={(e) => e.stopPropagation()}
                      onChange={(e) => setSubjectCounts((p) => ({ ...p, [s.id]: +e.target.value }))}
                      className="w-full accent-amber-400"
                    />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Difficulty */}
      <section className="mb-8">
        <div className="text-xs tracking-widest uppercase opacity-40 mb-3">Dificuldade</div>
        <div className="flex gap-2">
          {DIFFICULTIES.map((d) => {
            const active = selectedDiffs.includes(d.id);
            const color = d.id === "facil" ? "#4ade80" : d.id === "medio" ? "#fbbf24" : "#f87171";
            return (
              <button
                key={d.id}
                onClick={() => toggleItem(selectedDiffs, d.id, setSelectedDiffs)}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold border transition-all"
                style={active
                  ? { background: `${color}15`, border: `1px solid ${color}50`, color }
                  : { background: "#0d0f1a", border: "1px solid rgba(255,255,255,0.08)", opacity: 0.4 }}
              >
                {d.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* Years */}
      <section className="mb-8">
        <div className="text-xs tracking-widest uppercase opacity-40 mb-3">Anos da Prova</div>
        <div className="flex flex-wrap gap-2">
          {YEARS.map((y) => {
            const active = selectedYears.includes(y);
            return (
              <button
                key={y}
                onClick={() => toggleItem(selectedYears, y, setSelectedYears)}
                className="px-4 py-2 rounded-lg text-sm border transition-all"
                style={active
                  ? { background: "rgba(200,185,122,0.15)", border: "1px solid rgba(200,185,122,0.4)", color: "#c8b97a", fontWeight: 700 }
                  : { background: "#0d0f1a", border: "1px solid rgba(255,255,255,0.08)", opacity: 0.5 }}
              >
                {y}
              </button>
            );
          })}
        </div>
      </section>

      <button
        onClick={startQuiz}
        disabled={selectedDiffs.length === 0}
        className="w-full py-4 rounded-xl font-black text-sm uppercase tracking-wider transition-all disabled:opacity-30"
        style={{ background: "#c8b97a", color: "#0a0c14" }}
      >
        Iniciar Treino →
      </button>
    </div>
  );
}
