import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { kvSet } from '../lib/api';
import { Eye, EyeOff, Loader2 } from 'lucide-react';

export default function Landing() {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError('E-mail ou senha incorretos.');
    } else {
      navigate('/dashboard');
    }
    setLoading(false);
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    if (!name.trim()) { setError('Digite seu nome.'); setLoading(false); return; }
    if (password.length < 6) { setError('Senha deve ter no mínimo 6 caracteres.'); setLoading(false); return; }

    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) {
      setError(error.message.includes('already') ? 'E-mail já cadastrado.' : error.message);
      setLoading(false);
      return;
    }

    if (data.user) {
      try {
        await kvSet(`user:${data.user.id}:profile`, { name, email, createdAt: new Date().toISOString() });
      } catch {}
    }

    setSuccess('Conta criada! Faça login para continuar.');
    setTab('login');
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-[#080d1a] flex">
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-between w-[52%] bg-[#0a0f1e] border-r border-[#1e2d50] p-12 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-64 h-64 rounded-full bg-blue-500 blur-3xl" />
          <div className="absolute bottom-40 right-10 w-48 h-48 rounded-full bg-purple-500 blur-3xl" />
        </div>

        <div className="relative">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold font-display">ITA</span>
            </div>
            <span className="font-display font-bold text-white text-lg">ITA Study</span>
          </div>

          <h1 className="font-display text-5xl font-bold text-white leading-tight mb-6">
            Prepare-se para<br />
            <span className="gradient-text">o ITA</span>
          </h1>
          <p className="text-[#64748b] text-lg leading-relaxed max-w-sm">
            Questões reais de 2019–2025, correção inteligente com IA e simulados completos para Matemática, Física, Química e Inglês.
          </p>
        </div>

        <div className="relative space-y-4">
          {[
            { icon: '∑', label: 'Banco de questões', desc: '100+ questões das provas de 2019–2025' },
            { icon: '🧠', label: 'Correção com IA', desc: 'Entenda seus erros com explicações detalhadas' },
            { icon: '⏱', label: 'Simulados com pausa', desc: 'Continue de onde parou quando quiser' },
            { icon: '📈', label: 'Painel de desempenho', desc: 'Acompanhe sua evolução por matéria' },
          ].map(item => (
            <div key={item.label} className="flex items-start gap-3">
              <span className="text-xl w-7 shrink-0">{item.icon}</span>
              <div>
                <p className="text-white text-sm font-medium">{item.label}</p>
                <p className="text-[#64748b] text-xs">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel - form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-10">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm font-display">ITA</span>
            </div>
            <span className="font-display font-bold text-white">ITA Study</span>
          </div>

          <h2 className="font-display text-2xl font-bold text-white mb-1">
            {tab === 'login' ? 'Bem-vindo de volta' : 'Criar conta'}
          </h2>
          <p className="text-[#64748b] text-sm mb-8">
            {tab === 'login' ? 'Entre na sua conta para continuar' : 'Comece gratuitamente hoje'}
          </p>

          {/* Tabs */}
          <div className="flex bg-[#0f1629] border border-[#1e2d50] rounded-lg p-1 mb-6">
            <button
              onClick={() => { setTab('login'); setError(''); setSuccess(''); }}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${tab === 'login' ? 'bg-blue-600 text-white' : 'text-[#64748b] hover:text-white'}`}
            >
              Login
            </button>
            <button
              onClick={() => { setTab('register'); setError(''); setSuccess(''); }}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${tab === 'register' ? 'bg-blue-600 text-white' : 'text-[#64748b] hover:text-white'}`}
            >
              Cadastrar
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
              {error}
            </div>
          )}
          {success && (
            <div className="mb-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400 text-sm">
              {success}
            </div>
          )}

          <form onSubmit={tab === 'login' ? handleLogin : handleRegister} className="space-y-4">
            {tab === 'register' && (
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">Nome completo</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full bg-[#0f1629] border border-[#1e2d50] rounded-lg px-3 py-2.5 text-sm text-white placeholder-[#64748b] focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">E-mail</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="seu@email.com"
                required
                className="w-full bg-[#0f1629] border border-[#1e2d50] rounded-lg px-3 py-2.5 text-sm text-white placeholder-[#64748b] focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94a3b8] mb-1.5">Senha</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full bg-[#0f1629] border border-[#1e2d50] rounded-lg px-3 py-2.5 text-sm text-white placeholder-[#64748b] focus:outline-none focus:border-blue-500 transition-colors pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-white"
                >
                  {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 mt-2"
            >
              {loading && <Loader2 size={14} className="spin-slow" />}
              {tab === 'login' ? 'Entrar' : 'Criar conta'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
