import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "register" | "reset">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setError("Email ou senha incorretos.");
      else navigate("/dashboard");
    } else if (mode === "register") {
      if (password.length < 6) { setError("Senha deve ter ao menos 6 caracteres."); setLoading(false); return; }
      const { error } = await supabase.auth.signUp({
        email, password, options: { data: { name } }
      });
      if (error) setError(error.message);
      else setSuccess("Conta criada! Verifique seu email para confirmar o cadastro.");
    } else {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) setError(error.message);
      else setSuccess("Email de recuperação enviado!");
    }
    setLoading(false);
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: "#0a0c14", fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}
    >
      {/* Decorative grid */}
      <div className="fixed inset-0 pointer-events-none" style={{
        backgroundImage: "linear-gradient(rgba(200,185,122,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(200,185,122,0.03) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
      }} />

      <div className="relative w-full max-w-sm">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="text-5xl font-black tracking-tighter mb-2" style={{ color: "#c8b97a", letterSpacing: "-0.05em" }}>
            ITA
          </div>
          <div className="text-xs tracking-[0.4em] uppercase opacity-40 text-white">
            Plataforma de Estudos · 1ª Fase
          </div>
        </div>

        {/* Card */}
        <div className="rounded-2xl p-8 border border-white/8" style={{ background: "#0d0f1a" }}>
          {/* Tabs */}
          {mode !== "reset" && (
            <div className="flex mb-6 rounded-lg overflow-hidden border border-white/8">
              {(["login", "register"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => { setMode(m); setError(""); setSuccess(""); }}
                  className="flex-1 py-2 text-xs tracking-wider uppercase transition-all"
                  style={mode === m
                    ? { background: "rgba(200,185,122,0.15)", color: "#c8b97a", fontWeight: 700 }
                    : { color: "rgba(232,230,224,0.4)" }}
                >
                  {m === "login" ? "Entrar" : "Cadastrar"}
                </button>
              ))}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "register" && (
              <div>
                <label className="text-xs uppercase tracking-widest opacity-40 block mb-1.5">Nome</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome completo"
                  className="w-full px-4 py-2.5 rounded-lg text-sm bg-white/5 border border-white/10 text-white placeholder:opacity-20 focus:outline-none focus:border-amber-400/40 transition-colors"
                />
              </div>
            )}

            <div>
              <label className="text-xs uppercase tracking-widest opacity-40 block mb-1.5">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full px-4 py-2.5 rounded-lg text-sm bg-white/5 border border-white/10 text-white placeholder:opacity-20 focus:outline-none focus:border-amber-400/40 transition-colors"
              />
            </div>

            {mode !== "reset" && (
              <div>
                <label className="text-xs uppercase tracking-widest opacity-40 block mb-1.5">Senha</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-lg text-sm bg-white/5 border border-white/10 text-white placeholder:opacity-20 focus:outline-none focus:border-amber-400/40 transition-colors"
                />
              </div>
            )}

            {error && (
              <div className="text-xs px-3 py-2.5 rounded-lg" style={{ background: "rgba(239,68,68,0.1)", color: "#f87171", border: "1px solid rgba(239,68,68,0.2)" }}>
                {error}
              </div>
            )}
            {success && (
              <div className="text-xs px-3 py-2.5 rounded-lg" style={{ background: "rgba(34,197,94,0.1)", color: "#4ade80", border: "1px solid rgba(34,197,94,0.2)" }}>
                {success}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-lg text-sm font-bold tracking-wider uppercase transition-all disabled:opacity-50"
              style={{ background: "#c8b97a", color: "#0a0c14" }}
            >
              {loading ? "..." : mode === "login" ? "Entrar" : mode === "register" ? "Criar Conta" : "Enviar"}
            </button>
          </form>

          {mode === "login" && (
            <button
              onClick={() => { setMode("reset"); setError(""); setSuccess(""); }}
              className="mt-4 text-xs opacity-30 hover:opacity-60 transition-opacity w-full text-center"
            >
              Esqueci minha senha
            </button>
          )}
          {mode === "reset" && (
            <button
              onClick={() => setMode("login")}
              className="mt-4 text-xs opacity-30 hover:opacity-60 transition-opacity w-full text-center"
            >
              ← Voltar ao login
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
