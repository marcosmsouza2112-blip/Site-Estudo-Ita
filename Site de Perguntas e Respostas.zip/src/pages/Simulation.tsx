import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { kvGet, kvSet, getAICorrection } from '../lib/api';
import { getQuestions, Question, SUBJECTS, Subject, DIFFICULTIES, Difficulty } from '../data/questions';
import MathText from '../components/MathText';
import Timer from '../components/Timer';
import Navbar from '../components/Navbar';
import {
  Play, Pause, ChevronRight, ChevronLeft, CheckCircle2, XCircle,
  Beaker, Loader2, Sparkles, RotateCcw, Flag
} from 'lucide-react';

type AnswerKey = 'A' | 'B' | 'C' | 'D' | 'E';

interface SimState {
  id: string;
  questions: Question[];
  userAnswers: Record<string, AnswerKey>;
  currentIndex: number;
  elapsedSeconds: number;
  paused: boolean;
  completed: boolean;
  startedAt: string;
}

interface AIResult { explanation: string; howToSolve: string; tip: string; }

const SIM_QUESTION_COUNT = 20;

export default function Simulation() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState('');
  const [sim, setSim] = useState<SimState | null>(null);
  const [phase, setPhase] = useState<'setup' | 'active' | 'review'>('setup');
  const [hasSaved, setHasSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  // Setup options
  const [subjects, setSubjects] = useState<Subject[]>(['matematica', 'fisica', 'quimica', 'ingles']);
  const [difficulty, setDifficulty] = useState<Difficulty[]>(['facil', 'medio', 'dificil']);

  // Review state
  const [reviewIndex, setReviewIndex] = useState(0);
  const [aiResults, setAiResults] = useState<Record<string, AIResult>>({});
  const [aiLoading, setAiLoading] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { navigate('/'); return; }
      setUserId(data.user.id);

      // Load saved simulation
      const saved = await kvGet(`user:${data.user.id}:simulation`);
      if (saved && !saved.completed) {
        setSim(saved);
        setPhase('active');
        setHasSaved(true);
      }
      setLoading(false);
    };
    init();
  }, []);

  // Autosave every 10s when active
  useEffect(() => {
    if (!sim || sim.paused || sim.completed || !userId) return;
    const interval = setInterval(() => saveSim(sim), 10000);
    return () => clearInterval(interval);
  }, [sim, userId]);

  const saveSim = useCallback(async (s: SimState) => {
    if (!userId) return;
    setSaving(true);
    try {
      await kvSet(`user:${userId}:simulation`, s);
    } finally {
      setSaving(false);
    }
  }, [userId]);

  const handleStart = async () => {
    const qs = getQuestions({ subjects, difficulties: difficulty, count: SIM_QUESTION_COUNT });
    const newSim: SimState = {
      id: `sim_${Date.now()}`,
      questions: qs,
      userAnswers: {},
      currentIndex: 0,
      elapsedSeconds: 0,
      paused: false,
      completed: false,
      startedAt: new Date().toISOString(),
    };
    setSim(newSim);
    setPhase('active');
    await saveSim(newSim);
  };

  const handleResume = () => {
    if (!sim) return;
    const updated = { ...sim, paused: false };
    setSim(updated);
    saveSim(updated);
  };

  const handlePause = async () => {
    if (!sim) return;
    const updated = { ...sim, paused: true };
    setSim(updated);
    await saveSim(updated);
  };

  const handleTick = (s: number) => {
    setSim(prev => prev ? { ...prev, elapsedSeconds: s } : prev);
  };

  const handleAnswer = (key: AnswerKey) => {
    if (!sim) return;
    const updated = { ...sim, userAnswers: { ...sim.userAnswers, [sim.questions[sim.currentIndex].id]: key } };
    setSim(updated);
  };

  const handleNav = (dir: 1 | -1) => {
    if (!sim) return;
    const next = Math.max(0, Math.min(sim.questions.length - 1, sim.currentIndex + dir));
    const updated = { ...sim, currentIndex: next };
    setSim(updated);
    saveSim(updated);
  };

  const handleFinish = async () => {
    if (!sim || !userId) return;
    const completed: SimState = { ...sim, completed: true, paused: true };
    setSim(completed);
    await saveSim(completed);

    // Save session result
    const score = sim.questions.filter(q => sim.userAnswers[q.id] === q.answer).length;
    const sessionEntry = {
      id: sim.id,
      subject: 'all',
      score,
      total: sim.questions.length,
      date: new Date().toISOString(),
      mode: 'simulation',
    };
    const existing = await kvGet(`user:${userId}:sessions`) ?? [];
    await kvSet(`user:${userId}:sessions`, [...existing, sessionEntry]);

    setPhase('review');
    setReviewIndex(0);
  };

  const handleNewSim = async () => {
    if (userId) await kvSet(`user:${userId}:simulation`, null);
    setSim(null);
    setHasSaved(false);
    setPhase('setup');
    setAiResults({});
  };

  const loadAI = async (q: Question) => {
    if (aiResults[q.id] || !sim) return;
    const userAns = sim.userAnswers[q.id];
    if (!userAns || userAns === q.answer) return;

    setAiLoading(q.id);
    try {
      const result = await getAICorrection({
        question: q.statement,
        options: q.options,
        userAnswer: userAns,
        correctAnswer: q.answer,
        subject: q.subject,
        topic: q.topic,
        solution: q.solution,
      });
      setAiResults(prev => ({ ...prev, [q.id]: result }));
    } finally {
      setAiLoading(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#080d1a] flex items-center justify-center">
        <Loader2 size={24} className="text-blue-400 spin-slow" />
      </div>
    );
  }

  // ── SETUP ───────────────────────────────────────────────────────
  if (phase === 'setup') {
    return (
      <div className="min-h-screen bg-[#080d1a]">
        <Navbar />
        <div className="max-w-xl mx-auto px-4 py-10">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
                <Beaker size={20} className="text-purple-400" />
              </div>
              <div>
                <h1 className="font-display text-2xl font-bold text-white">Simulado ITA</h1>
                <p className="text-[#64748b] text-sm">Prova completa com {SIM_QUESTION_COUNT} questões</p>
              </div>
            </div>
          </div>

          {hasSaved && sim && (
            <div className="mb-6 bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
              <p className="text-yellow-400 font-semibold text-sm mb-1">Simulado em andamento</p>
              <p className="text-[#94a3b8] text-xs mb-3">
                {Object.keys(sim.userAnswers).length}/{sim.questions.length} questões respondidas
                · {Math.floor(sim.elapsedSeconds / 60)}min {sim.elapsedSeconds % 60}s
              </p>
              <button
                onClick={handleResume}
                className="flex items-center gap-2 px-4 py-2 bg-yellow-500 text-black text-sm font-semibold rounded-lg hover:bg-yellow-400 transition-colors"
              >
                <Play size={14} /> Retomar simulado
              </button>
            </div>
          )}

          <div className="space-y-6">
            <div>
              <h2 className="text-sm font-semibold text-[#94a3b8] uppercase tracking-wider mb-3">Matérias incluídas</h2>
              <div className="grid grid-cols-2 gap-2">
                {SUBJECTS.map(sub => {
                  const active = subjects.includes(sub.id);
                  return (
                    <button
                      key={sub.id}
                      onClick={() => setSubjects(s => s.includes(sub.id) ? s.filter(x => x !== sub.id) : [...s, sub.id])}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all text-left flex items-center gap-2 ${
                        active ? 'text-white' : 'border-[#1e2d50] text-[#64748b] bg-[#0f1629]'
                      }`}
                      style={active ? { borderColor: sub.color + '80', backgroundColor: sub.color + '15' } : {}}
                    >
                      <span>{sub.emoji}</span> {sub.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <h2 className="text-sm font-semibold text-[#94a3b8] uppercase tracking-wider mb-3">Dificuldade</h2>
              <div className="flex gap-2">
                {DIFFICULTIES.map(d => {
                  const active = difficulty.includes(d.id);
                  return (
                    <button
                      key={d.id}
                      onClick={() => setDifficulty(s => s.includes(d.id) ? s.filter(x => x !== d.id) : [...s, d.id])}
                      className={`flex-1 py-2.5 rounded-lg border text-sm font-medium transition-all ${
                        active ? '' : 'border-[#1e2d50] text-[#64748b] bg-[#0f1629]'
                      }`}
                      style={active ? { borderColor: d.color + '80', backgroundColor: d.color + '15', color: d.color } : {}}
                    >
                      {d.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              onClick={handleStart}
              disabled={!subjects.length}
              className="w-full py-3.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <Play size={16} /> Iniciar novo simulado
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── ACTIVE SIMULATION ─────────────────────────────────────────
  if (phase === 'active' && sim) {
    const current = sim.questions[sim.currentIndex];
    const answered = Object.keys(sim.userAnswers).length;
    const sub = SUBJECTS.find(s => s.id === current.subject);
    const optKeys: AnswerKey[] = ['A', 'B', 'C', 'D', 'E'];
    const userAns = sim.userAnswers[current.id];
    const progress = (answered / sim.questions.length) * 100;

    return (
      <div className="min-h-screen bg-[#080d1a]">
        <Navbar />
        <div className="h-0.5 bg-[#1a2240]">
          <div className="h-full bg-purple-500 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>

        <div className="max-w-2xl mx-auto px-4 py-6 fade-in">
          {/* Top bar */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Timer
                seconds={sim.elapsedSeconds}
                onTick={s => handleTick(s)}
                paused={sim.paused}
              />
              <span className="text-xs text-[#64748b]">{answered}/{sim.questions.length} respondidas</span>
              {saving && <span className="text-xs text-[#64748b] pulse-dot">Salvando...</span>}
            </div>
            <div className="flex items-center gap-2">
              {sim.paused ? (
                <button
                  onClick={handleResume}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-green-600/20 border border-green-500/30 text-green-400 text-xs rounded-lg hover:bg-green-600/30 transition-colors"
                >
                  <Play size={12} /> Retomar
                </button>
              ) : (
                <button
                  onClick={handlePause}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1a2240] border border-[#2a3a60] text-[#94a3b8] text-xs rounded-lg hover:border-[#3a4a70] transition-colors"
                >
                  <Pause size={12} /> Pausar
                </button>
              )}
              <button
                onClick={handleFinish}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600/20 border border-purple-500/30 text-purple-400 text-xs rounded-lg hover:bg-purple-600/30 transition-colors"
              >
                <Flag size={12} /> Finalizar
              </button>
            </div>
          </div>

          {/* Paused overlay */}
          {sim.paused && (
            <div className="mb-6 text-center py-8 bg-[#0f1629] border border-[#1e2d50] rounded-2xl">
              <Pause size={32} className="text-[#64748b] mx-auto mb-3" />
              <p className="text-white font-semibold mb-1">Simulado pausado</p>
              <p className="text-[#64748b] text-sm mb-4">Seu progresso foi salvo. Continue quando quiser.</p>
              <button onClick={handleResume} className="px-5 py-2.5 bg-purple-600 text-white rounded-xl text-sm font-semibold hover:bg-purple-500 transition-colors flex items-center gap-2 mx-auto">
                <Play size={14} /> Retomar
              </button>
            </div>
          )}

          {!sim.paused && (
            <>
              {/* Question number map */}
              <div className="flex flex-wrap gap-1.5 mb-5 p-3 bg-[#0f1629] border border-[#1e2d50] rounded-xl">
                {sim.questions.map((q, i) => {
                  const ans = sim.userAnswers[q.id];
                  return (
                    <button
                      key={q.id}
                      onClick={() => setSim(s => s ? { ...s, currentIndex: i } : s)}
                      className={`w-7 h-7 rounded text-xs font-mono font-bold transition-colors ${
                        i === sim.currentIndex ? 'bg-purple-600 text-white' :
                        ans ? 'bg-blue-600/30 text-blue-300 border border-blue-500/30' :
                        'bg-[#1a2240] text-[#64748b] hover:bg-[#2a3250]'
                      }`}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>

              {/* Meta */}
              <div className="flex items-center gap-2 mb-4">
                <span className="text-lg">{sub?.emoji}</span>
                <span className="text-sm text-[#94a3b8]">{sub?.label}</span>
                <span className="text-[#1e2d50]">·</span>
                <span className="text-xs text-[#64748b]">ITA {current.year} · {current.topic}</span>
                <span className="ml-auto text-sm font-mono text-[#64748b]">Q{sim.currentIndex + 1}</span>
              </div>

              {/* Question */}
              <div className="bg-[#0f1629] border border-[#1e2d50] rounded-2xl p-6 mb-4">
                <MathText text={current.statement} className="text-white text-base leading-relaxed" block />
              </div>

              {/* Options */}
              <div className="space-y-2 mb-6">
                {optKeys.map(key => {
                  const isSelected = userAns === key;
                  return (
                    <button
                      key={key}
                      onClick={() => handleAnswer(key)}
                      className={`option-btn w-full text-left flex items-start gap-3 p-4 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-purple-600/20 border-purple-500/60 text-white'
                          : 'bg-[#0f1629] border-[#1e2d50] text-[#94a3b8] hover:border-[#2a3a60] hover:text-white'
                      }`}
                    >
                      <span className={`shrink-0 w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold font-mono ${
                        isSelected ? 'bg-purple-600 text-white' : 'bg-[#1a2240] text-[#64748b]'
                      }`}>{key}</span>
                      <MathText text={current.options[key]} className="flex-1 text-sm leading-relaxed pt-0.5" />
                    </button>
                  );
                })}
              </div>

              {/* Nav */}
              <div className="flex gap-3">
                <button
                  onClick={() => handleNav(-1)}
                  disabled={sim.currentIndex === 0}
                  className="flex items-center gap-1.5 px-4 py-2.5 bg-[#0f1629] border border-[#1e2d50] rounded-xl text-[#94a3b8] text-sm hover:border-[#2a3a60] disabled:opacity-40 transition-colors"
                >
                  <ChevronLeft size={14} /> Anterior
                </button>
                <button
                  onClick={() => handleNav(1)}
                  disabled={sim.currentIndex === sim.questions.length - 1}
                  className="flex items-center gap-1.5 px-4 py-2.5 bg-[#0f1629] border border-[#1e2d50] rounded-xl text-[#94a3b8] text-sm hover:border-[#2a3a60] disabled:opacity-40 transition-colors ml-auto"
                >
                  Próxima <ChevronRight size={14} />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  // ── REVIEW ────────────────────────────────────────────────────
  if (phase === 'review' && sim) {
    const score = sim.questions.filter(q => sim.userAnswers[q.id] === q.answer).length;
    const total = sim.questions.length;
    const pct = Math.round((score / total) * 100);
    const elapsed = sim.elapsedSeconds;
    const optKeys: AnswerKey[] = ['A', 'B', 'C', 'D', 'E'];

    const reviewQ = sim.questions[reviewIndex];
    const userAns = sim.userAnswers[reviewQ.id];
    const isCorrect = userAns === reviewQ.answer;
    const sub = SUBJECTS.find(s => s.id === reviewQ.subject);
    const aiResult = aiResults[reviewQ.id];

    return (
      <div className="min-h-screen bg-[#080d1a]">
        <Navbar />
        <div className="max-w-3xl mx-auto px-4 py-8">
          {/* Results header */}
          <div className="text-center mb-8">
            <div className="text-5xl mb-4">{pct >= 80 ? '🏆' : pct >= 60 ? '⭐' : '📚'}</div>
            <h1 className="font-display text-4xl font-bold text-white mb-1">{score}/{total}</h1>
            <p className="text-[#64748b]">
              Acurácia: <span className="font-bold" style={{ color: pct >= 70 ? '#10b981' : pct >= 50 ? '#f59e0b' : '#ef4444' }}>{pct}%</span>
              {' '}· Tempo: {Math.floor(elapsed / 60)}min {elapsed % 60}s
            </p>
          </div>

          {/* Question selector */}
          <div className="flex flex-wrap gap-1.5 p-3 bg-[#0f1629] border border-[#1e2d50] rounded-xl mb-6">
            {sim.questions.map((q, i) => {
              const ua = sim.userAnswers[q.id];
              const correct = ua === q.answer;
              return (
                <button
                  key={q.id}
                  onClick={() => { setReviewIndex(i); loadAI(q); }}
                  className={`w-7 h-7 rounded text-xs font-mono font-bold transition-colors ${
                    i === reviewIndex ? 'ring-2 ring-white ring-offset-1 ring-offset-[#0f1629]' : ''
                  } ${!ua ? 'bg-[#1a2240] text-[#64748b]' : correct ? 'bg-green-500/30 text-green-300' : 'bg-red-500/30 text-red-300'}`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          {/* Question review */}
          <div className="bg-[#0f1629] border border-[#1e2d50] rounded-2xl p-6 mb-4 fade-in" key={reviewIndex}>
            <div className="flex items-center gap-2 mb-4">
              <span>{sub?.emoji}</span>
              <span className="text-sm text-[#94a3b8]">{sub?.label} · ITA {reviewQ.year} · {reviewQ.topic}</span>
              <span className="ml-auto">
                {isCorrect
                  ? <CheckCircle2 size={16} className="text-green-400" />
                  : userAns
                    ? <XCircle size={16} className="text-red-400" />
                    : <span className="text-xs text-[#64748b]">não respondida</span>
                }
              </span>
            </div>
            <MathText text={reviewQ.statement} className="text-white text-sm leading-relaxed mb-5" block />

            <div className="space-y-2">
              {optKeys.map(key => {
                const isAns = key === reviewQ.answer;
                const isUser = key === userAns;
                let cls = 'flex items-start gap-3 p-3 rounded-xl border text-sm ';
                if (isAns) cls += 'bg-green-500/10 border-green-500/30 text-green-300';
                else if (isUser && !isAns) cls += 'bg-red-500/10 border-red-500/30 text-red-300';
                else cls += 'bg-[#1a2240] border-[#1e2d50] text-[#64748b] opacity-60';
                return (
                  <div key={key} className={cls}>
                    <span className={`shrink-0 w-5 h-5 rounded flex items-center justify-center text-xs font-bold ${
                      isAns ? 'bg-green-500 text-white' : isUser ? 'bg-red-500 text-white' : 'bg-[#2a3250] text-[#64748b]'
                    }`}>{key}</span>
                    <MathText text={reviewQ.options[key]} className="flex-1 text-xs leading-relaxed" />
                    {isAns && <CheckCircle2 size={12} className="text-green-400 shrink-0 mt-0.5" />}
                    {isUser && !isAns && <XCircle size={12} className="text-red-400 shrink-0 mt-0.5" />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* AI Correction */}
          {!isCorrect && userAns && (
            <div className="bg-[#0f1629] border border-[#1e2d50] rounded-2xl overflow-hidden mb-4">
              <div className="flex items-center justify-between px-5 py-3 border-b border-[#1a2240] bg-[#1a2240]/50">
                <div className="flex items-center gap-2">
                  <Sparkles size={14} className="text-yellow-400" />
                  <span className="text-sm font-semibold text-white">Correção Inteligente</span>
                </div>
                {!aiResult && !aiLoading && (
                  <button
                    onClick={() => loadAI(reviewQ)}
                    className="text-xs text-blue-400 hover:text-blue-300"
                  >
                    Gerar explicação
                  </button>
                )}
                {aiLoading === reviewQ.id && <Loader2 size={12} className="text-[#64748b] spin-slow" />}
              </div>
              {aiResult ? (
                <div className="p-5 space-y-4">
                  <div>
                    <p className="text-xs font-semibold text-red-400 uppercase tracking-wider mb-1.5">❌ Por que está errado</p>
                    <p className="text-sm text-[#94a3b8] leading-relaxed">{aiResult.explanation}</p>
                  </div>
                  <div className="border-t border-[#1a2240] pt-4">
                    <p className="text-xs font-semibold text-green-400 uppercase tracking-wider mb-1.5">✅ Como resolver</p>
                    <p className="text-sm text-[#94a3b8] leading-relaxed whitespace-pre-line">{aiResult.howToSolve}</p>
                  </div>
                  <div className="border-t border-[#1a2240] pt-4">
                    <p className="text-xs font-semibold text-yellow-400 uppercase tracking-wider mb-1.5">💡 Dica</p>
                    <p className="text-sm text-[#94a3b8] leading-relaxed">{aiResult.tip}</p>
                  </div>
                </div>
              ) : (
                !aiLoading && (
                  <div className="px-5 py-4">
                    <p className="text-sm text-[#64748b]">{reviewQ.solution}</p>
                  </div>
                )
              )}
            </div>
          )}

          {/* Nav + actions */}
          <div className="flex gap-3">
            <button onClick={() => { setReviewIndex(i => Math.max(0, i - 1)); }} disabled={reviewIndex === 0}
              className="flex items-center gap-1 px-4 py-2.5 bg-[#0f1629] border border-[#1e2d50] rounded-xl text-[#94a3b8] text-sm disabled:opacity-40">
              <ChevronLeft size={14} /> Anterior
            </button>
            <button onClick={() => { setReviewIndex(i => Math.min(sim.questions.length - 1, i + 1)); loadAI(sim.questions[Math.min(sim.questions.length - 1, reviewIndex + 1)]); }}
              disabled={reviewIndex === sim.questions.length - 1}
              className="flex items-center gap-1 px-4 py-2.5 bg-[#0f1629] border border-[#1e2d50] rounded-xl text-[#94a3b8] text-sm disabled:opacity-40">
              Próxima <ChevronRight size={14} />
            </button>
            <button onClick={handleNewSim}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-purple-600 text-white text-sm rounded-xl hover:bg-purple-500 ml-auto">
              <RotateCcw size={14} /> Novo simulado
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
