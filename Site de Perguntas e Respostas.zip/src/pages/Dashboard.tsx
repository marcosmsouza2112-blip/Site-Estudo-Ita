import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import type { User } from "@supabase/supabase-js";
import { getAnswers, getSimulados, type AnswerRecord, type SimuladoState } from "../lib/store";
import { SUBJECTS } from "../data/questions";

type Props = { user: User };

export default function Dashboard({ user }: Props) {
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [simulados, setSimulados] = useState<SimuladoState[]>([]);

  useEffect(() => {
    getAnswers(user.id).then(setAnswers);
    getSimulados(user.id).then(setSimulados);
  }, [user.id]);

  const total = answers.length;
  const correct = answers.filter((a) => a.correct).length;
  const rate = total ? Math.round((correct / total) * 100) : 0;
  const name = user.user_metadata?.name || user.email?.split("@")[0] || "Aluno";
  const pendingSimulados = simulados.filter((s) => !s.completedAt);

  const subjectStats = SUBJECTS.map((s) => {
    const sub = answers.filter((a) => a.subject === s.id);
    const c = sub.filter((a) => a.correct).length;
    return { ...s, total: sub.length, correct: c, rate: sub.length ? Math.round((c / sub.length) * 100) : 0 };
  });

  const recentErrors = answers.filter((a) => !a.correct).slice(-5).reverse();

  const SUBJECT_COLORS: Record<string, string> = {
    blue: "#60a5fa", purple: "#c084fc", green: "#4ade80", amber: "#fbbf24"
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="text-xs tracking-[0.3em] uppercase opacity-30 mb-1">Bem-vindo,</div>
        <h1 className="text-2xl font-bold" style={{ color: "#c8b97a" }}>{name}</h1>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Questões Respondidas", value: total, unit: "" },
          { label: "Acertos", value: correct, unit: "" },
          { label: "Taxa de Acerto", value: rate, unit: "%" },
          { label: "Simulados Ativos", value: pendingSimulados.length, unit: "" },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl p-5 border border-white/8" style={{ background: "#0d0f1a" }}>
            <div className="text-2xl font-black mb-1" style={{ color: "#c8b97a" }}>
              {stat.value}{stat.unit}
            </div>
            <div className="text-xs opacity-40">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="grid md:grid-cols-2 gap-4 mb-8">
        <Link to="/treino" className="rounded-xl p-6 border border-white/8 hover:border-amber-400/30 transition-all group" style={{ background: "#0d0f1a" }}>
          <div className="text-2xl mb-3">✎</div>
          <div className="font-bold mb-1 group-hover:text-amber-300 transition-colors">Iniciar Treino</div>
          <div className="text-xs opacity-40">Selecione matérias, anos e dificuldade</div>
        </Link>
        <Link to="/simulado" className="rounded-xl p-6 border border-white/8 hover:border-amber-400/30 transition-all group" style={{ background: "#0d0f1a" }}>
          <div className="text-2xl mb-3">⏱</div>
          <div className="font-bold mb-1 group-hover:text-amber-300 transition-colors">Iniciar Simulado</div>
          <div className="text-xs opacity-40">Prova completa com cronômetro e pausa</div>
        </Link>
      </div>

      {/* Subject performance */}
      <div className="rounded-xl border border-white/8 mb-6" style={{ background: "#0d0f1a" }}>
        <div className="px-5 py-4 border-b border-white/8">
          <div className="text-xs tracking-[0.25em] uppercase opacity-40">Desempenho por Matéria</div>
        </div>
        <div className="p-5 grid md:grid-cols-2 gap-4">
          {subjectStats.map((s) => (
            <div key={s.id}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span style={{ color: SUBJECT_COLORS[s.color] }}>{s.icon}</span>
                  <span className="text-sm font-medium">{s.label}</span>
                </div>
                <span className="text-sm font-bold" style={{ color: SUBJECT_COLORS[s.color] }}>
                  {s.rate}% ({s.correct}/{s.total})
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-white/8">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${s.rate}%`, background: SUBJECT_COLORS[s.color] }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pending simulados */}
      {pendingSimulados.length > 0 && (
        <div className="rounded-xl border border-amber-400/20 p-5" style={{ background: "rgba(200,185,122,0.05)" }}>
          <div className="text-xs tracking-widest uppercase mb-3" style={{ color: "#c8b97a", opacity: 0.8 }}>
            Simulados em Andamento
          </div>
          {pendingSimulados.map((s) => (
            <div key={s.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
              <div>
                <div className="text-sm font-medium">{s.name}</div>
                <div className="text-xs opacity-40">
                  {Object.keys(s.answers).length}/{s.questions.length} respondidas
                </div>
              </div>
              <Link
                to={`/simulado/prova/${s.id}`}
                className="text-xs px-3 py-1.5 rounded-lg font-bold"
                style={{ background: "rgba(200,185,122,0.2)", color: "#c8b97a" }}
              >
                Continuar →
              </Link>
            </div>
          ))}
        </div>
      )}

      {/* Recent errors */}
      {recentErrors.length > 0 && (
        <div className="mt-6 rounded-xl border border-white/8 p-5" style={{ background: "#0d0f1a" }}>
          <div className="text-xs tracking-widest uppercase opacity-40 mb-3">Últimos Erros</div>
          {recentErrors.map((a) => (
            <div key={a.questionId} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
              <div className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0" />
              <div className="text-xs opacity-60">{a.subject} · {a.year} · {a.topic}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
