import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { SUBJECTS, DIFFICULTIES, YEARS, Subject, Difficulty } from '../data/questions';
import { ChevronRight, CheckSquare, Square } from 'lucide-react';

export default function StudySetup() {
  const navigate = useNavigate();
  const [subjects, setSubjects] = useState<Subject[]>(['matematica']);
  const [difficulties, setDifficulties] = useState<Difficulty[]>(['facil', 'medio', 'dificil']);
  const [years, setYears] = useState<number[]>(YEARS);
  const [count, setCount] = useState(10);

  const toggle = <T,>(arr: T[], val: T, set: (v: T[]) => void) => {
    set(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);
  };

  const handleStart = () => {
    if (!subjects.length) return;
    const params = new URLSearchParams({
      subjects: subjects.join(','),
      difficulties: difficulties.join(','),
      years: years.join(','),
      count: String(count),
      mode: 'study',
    });
    navigate(`/quiz?${params}`);
  };

  return (
    <div className="min-h-screen bg-[#080d1a]">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 py-10">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-white mb-2">Modo Treino</h1>
          <p className="text-[#64748b]">Configure sua sessão de estudo</p>
        </div>

        {/* Subjects */}
        <section className="mb-7">
          <h2 className="text-sm font-semibold text-[#94a3b8] uppercase tracking-wider mb-3">Matérias</h2>
          <div className="grid grid-cols-2 gap-2">
            {SUBJECTS.map(sub => {
              const active = subjects.includes(sub.id);
              return (
                <button
                  key={sub.id}
                  onClick={() => toggle(subjects, sub.id, setSubjects)}
                  className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all text-left ${
                    active ? 'border-opacity-50 bg-opacity-10' : 'border-[#1e2d50] bg-[#0f1629] hover:border-[#2a3a60]'
                  }`}
                  style={active ? { borderColor: sub.color + '80', backgroundColor: sub.color + '15' } : {}}
                >
                  <span className="text-xl w-7 text-center">{sub.emoji}</span>
                  <span className={`font-medium text-sm ${active ? 'text-white' : 'text-[#94a3b8]'}`}>{sub.label}</span>
                  {active
                    ? <CheckSquare size={15} className="ml-auto" style={{ color: sub.color }} />
                    : <Square size={15} className="ml-auto text-[#1e2d50]" />
                  }
                </button>
              );
            })}
          </div>
        </section>

        {/* Difficulties */}
        <section className="mb-7">
          <h2 className="text-sm font-semibold text-[#94a3b8] uppercase tracking-wider mb-3">Dificuldade</h2>
          <div className="flex gap-2">
            {DIFFICULTIES.map(d => {
              const active = difficulties.includes(d.id);
              return (
                <button
                  key={d.id}
                  onClick={() => toggle(difficulties, d.id, setDifficulties)}
                  className={`flex-1 py-2.5 rounded-lg border text-sm font-medium transition-all ${
                    active ? 'text-white border-opacity-50' : 'border-[#1e2d50] text-[#64748b] bg-[#0f1629] hover:border-[#2a3a60]'
                  }`}
                  style={active ? { borderColor: d.color + '80', backgroundColor: d.color + '15', color: d.color } : {}}
                >
                  {d.label}
                </button>
              );
            })}
          </div>
        </section>

        {/* Years */}
        <section className="mb-7">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-[#94a3b8] uppercase tracking-wider">Anos</h2>
            <button
              onClick={() => setYears(years.length === YEARS.length ? [] : [...YEARS])}
              className="text-xs text-blue-400 hover:text-blue-300"
            >
              {years.length === YEARS.length ? 'Desmarcar todos' : 'Selecionar todos'}
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {YEARS.map(y => {
              const active = years.includes(y);
              return (
                <button
                  key={y}
                  onClick={() => toggle(years, y, setYears)}
                  className={`px-3 py-1.5 rounded-lg border text-sm font-medium transition-all ${
                    active
                      ? 'bg-blue-600/20 border-blue-500/50 text-blue-300'
                      : 'border-[#1e2d50] text-[#64748b] bg-[#0f1629] hover:border-[#2a3a60]'
                  }`}
                >
                  {y}
                </button>
              );
            })}
          </div>
        </section>

        {/* Question count */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-[#94a3b8] uppercase tracking-wider">Número de questões</h2>
            <span className="text-white font-bold text-lg font-display">{count}</span>
          </div>
          <input
            type="range"
            min={5}
            max={40}
            step={5}
            value={count}
            onChange={e => setCount(Number(e.target.value))}
            className="w-full h-1.5 bg-[#1a2240] rounded-full appearance-none cursor-pointer accent-blue-500"
          />
          <div className="flex justify-between text-xs text-[#64748b] mt-1">
            <span>5</span><span>10</span><span>15</span><span>20</span><span>25</span><span>30</span><span>35</span><span>40</span>
          </div>
        </section>

        {/* Start */}
        <button
          onClick={handleStart}
          disabled={!subjects.length || !difficulties.length || !years.length}
          className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          Iniciar sessão com {count} questões
          <ChevronRight size={18} />
        </button>
        {!subjects.length && (
          <p className="text-center text-red-400 text-sm mt-2">Selecione ao menos uma matéria</p>
        )}
      </div>
    </div>
  );
}
