import { useEffect, useState, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { kvGet, kvSet, getAICorrection } from '../lib/api';
import { getQuestions, Question, SUBJECTS, Subject, Difficulty } from '../data/questions';
import MathText from '../components/MathText';
import Navbar from '../components/Navbar';
import { CheckCircle2, XCircle, ChevronRight, Sparkles, Loader2, RotateCcw } from 'lucide-react';

type AnswerKey = 'A' | 'B' | 'C' | 'D' | 'E';

interface AIResult {
  explanation: string;
  howToSolve: string;
  tip: string;
}

interface QuizState {
  questions: Question[];
  currentIndex: number;
  answers: Record<string, AnswerKey | null>;
  scores: Record<string, boolean>;
  completed: boolean;
}

export default function Quiz() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [state, setState] = useState<QuizState | null>(null);
  const [selected, setSelected] = useState<AnswerKey | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [aiResult, setAiResult] = useState<AIResult | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [userId, setUserId] = useState('');
  const [sessionId] = useState(() => `session_${Date.now()}`);

  useEffect(() => {
    const init = async () => {
      const { data } = await supabase.auth.getUser();
      if (data.user) setUserId(data.user.id);
    };
    init();

    const subjects = (params.get('subjects') || 'matematica').split(',') as Subject[];
    const difficulties = (params.get('difficulties') || 'facil,medio,dificil').split(',') as Difficulty[];
    const years = (params.get('years') || '').split(',').map(Number).filter(Boolean);
    const count = parseInt(params.get('count') || '10');

    const qs = getQuestions({ subjects, difficulties, years: years.length ? years : undefined, count });

    setState({
      questions: qs,
      currentIndex: 0,
      answers: {},
      scores: {},
      completed: false,
    });
  }, []);

  const current = state?.questions[state.currentIndex];

  const handleSelect = (opt: AnswerKey) => {
    if (revealed) return;
    setSelected(opt);
  };

  const handleReveal = async () => {
    if (!selected || !current || !state) return;
    setRevealed(true);
    const correct = selected === current.answer;

    const newAnswers = { ...state.answers, [current.id]: selected };
    const newScores = { ...state.scores, [current.id]: correct };

    setState(s => s ? { ...s, answers: newAnswers, scores: newScores } : s);

    if (!correct) {
      setAiLoading(true);
      try {
        const result = await getAICorrection({
          question: current.statement,
          options: current.options,
          userAnswer: selected,
          correctAnswer: current.answer,
          subject: current.subject,
          topic: current.topic,
          solution: current.solution,
        });
        setAiResult(result);
      } finally {
        setAiLoading(false);
      }
    }
  };

  const handleNext = useCallback(async () => {
    if (!state) return;
    setSelected(null);
    setRevealed(false);
    setAiResult(null);

    const nextIndex = state.currentIndex + 1;
    const completed = nextIndex >= state.questions.length;

    setState(s => s ? { ...s, currentIndex: nextIndex, completed } : s);

    if (completed && userId) {
      const totalScore = Object.values(state.scores).filter(Boolean).length;
      const sessionEntry = {
        id: sessionId,
        subject: params.get('subjects')?.split(',')[0] || 'matematica',
        score: totalScore,
        total: state.questions.length,
        date: new Date().toISOString(),
        mode: params.get('mode') || 'study',
        answers: state.answers,
      };

      const existing = await kvGet(`user:${userId}:sessions`) ?? [];
      await kvSet(`user:${userId}:sessions`, [...existing, sessionEntry]);
    }
  }, [state, userId, sessionId]);

  if (!state) {
    return (
      <div className="min-h-screen bg-[#080d1a] flex items-center justify-center">
        <Loader2 size={24} className="text-blue-400 spin-slow" />
      </div>
    );
  }

  // Results screen
  if (state.completed) {
    const total = state.questions.length;
    const score = Object.values(state.scores).filter(Boolean).length;
    const pct = Math.round((score / total) * 100);

    return (
      <div className="min-h-screen bg-[#080d1a]">
        <Navbar />
        <div className="max-w-xl mx-auto px-4 py-16 text-center fade-in">
          <div className="text-6xl mb-6">
            {pct >= 80 ? '🏆' : pct >= 60 ? '⭐' : '📚'}
          </div>
          <h1 className="font-display text-4xl font-bold text-white mb-2">
            {score}/{total}
          </h1>
          <p className="text-[#64748b] text-lg mb-6">
            Taxa de acerto: <span className="font-bold" style={{ color: pct >= 70 ? '#10b981' : pct >= 50 ? '#f59e0b' : '#ef4444' }}>{pct}%</span>
          </p>
          <div className="bg-[#0f1629] border border-[#1e2d50] rounded-xl p-4 mb-6 text-left">
            {state.questions.map((q, i) => {
              const userAns = state.answers[q.id];
              const correct = state.scores[q.id];
              const sub = SUBJECTS.find(s => s.id === q.subject);
              return (
                <div key={q.id} className="flex items-center gap-3 py-2 border-b border-[#1a2240] last:border-0">
                  <span className="text-sm text-[#64748b] w-5">{i + 1}.</span>
                  {correct
                    ? <CheckCircle2 size={14} className="text-green-400 shrink-0" />
                    : <XCircle size={14} className="text-red-400 shrink-0" />
                  }
                  <span className="text-xs text-[#94a3b8] flex-1 truncate">{sub?.emoji} {q.topic}</span>
                  <span className="text-xs font-mono text-[#64748b]">{userAns || '—'} → {q.answer}</span>
                </div>
              );
            })}
          </div>
          <div className="flex gap-3 justify-center">
            <button
              onClick={() => navigate('/study')}
              className="flex items-center gap-2 px-5 py-2.5 bg-[#0f1629] border border-[#1e2d50] rounded-xl text-white text-sm hover:border-blue-500/40 transition-colors"
            >
              <RotateCcw size={14} /> Nova sessão
            </button>
            <button
              onClick={() => navigate('/dashboard')}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 rounded-xl text-white text-sm hover:bg-blue-500 transition-colors"
            >
              Ir ao início <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!current) return null;

  const sub = SUBJECTS.find(s => s.id === current.subject);
  const progress = ((state.currentIndex) / state.questions.length) * 100;
  const optionKeys: AnswerKey[] = ['A', 'B', 'C', 'D', 'E'];
  const isCorrect = revealed && selected === current.answer;

  return (
    <div className="min-h-screen bg-[#080d1a]">
      <Navbar />

      {/* Progress bar */}
      <div className="h-0.5 bg-[#1a2240]">
        <div
          className="h-full bg-blue-500 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8 fade-in">
        {/* Meta */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <span className="text-lg">{sub?.emoji}</span>
            <span className="text-sm text-[#94a3b8]">{sub?.label}</span>
            <span className="text-[#1e2d50]">·</span>
            <span
              className="text-xs font-medium px-2 py-0.5 rounded-full"
              style={{
                backgroundColor: current.difficulty === 'facil' ? '#10b98115' : current.difficulty === 'medio' ? '#f59e0b15' : '#ef444415',
                color: current.difficulty === 'facil' ? '#10b981' : current.difficulty === 'medio' ? '#f59e0b' : '#ef4444',
              }}
            >
              {current.difficulty === 'facil' ? 'Fácil' : current.difficulty === 'medio' ? 'Médio' : 'Difícil'}
            </span>
            <span className="text-[#1e2d50]">·</span>
            <span className="text-xs text-[#64748b]">ITA {current.year}</span>
          </div>
          <span className="text-sm text-[#64748b] font-mono">
            {state.currentIndex + 1} / {state.questions.length}
          </span>
        </div>

        {/* Question */}
        <div className="bg-[#0f1629] border border-[#1e2d50] rounded-2xl p-6 mb-5">
          <p className="text-xs text-[#64748b] uppercase tracking-wider mb-3 font-semibold">{current.topic}</p>
          <MathText text={current.statement} className="text-white text-base leading-relaxed" block />
        </div>

        {/* Options */}
        <div className="space-y-2.5 mb-6">
          {optionKeys.map(key => {
            const optText = current.options[key];
            const isSelected = selected === key;
            const isAnswer = current.answer === key;

            let className = 'option-btn w-full text-left flex items-start gap-3 p-4 rounded-xl border transition-all ';

            if (!revealed) {
              className += isSelected
                ? 'bg-blue-600/20 border-blue-500/60 text-white'
                : 'bg-[#0f1629] border-[#1e2d50] text-[#94a3b8] hover:border-[#2a3a60] hover:text-white';
            } else if (isAnswer) {
              className += 'bg-green-500/10 border-green-500/60 text-green-300';
            } else if (isSelected && !isAnswer) {
              className += 'bg-red-500/10 border-red-500/60 text-red-300';
            } else {
              className += 'bg-[#0f1629] border-[#1e2d50] text-[#64748b] opacity-60';
            }

            return (
              <button
                key={key}
                onClick={() => handleSelect(key)}
                disabled={revealed}
                className={className}
              >
                <span className={`shrink-0 w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold font-mono ${
                  !revealed && isSelected ? 'bg-blue-600 text-white' :
                  revealed && isAnswer ? 'bg-green-500 text-white' :
                  revealed && isSelected && !isAnswer ? 'bg-red-500 text-white' :
                  'bg-[#1a2240] text-[#64748b]'
                }`}>
                  {key}
                </span>
                <MathText text={optText} className="flex-1 text-sm leading-relaxed pt-0.5" />
                {revealed && isAnswer && <CheckCircle2 size={16} className="text-green-400 shrink-0 mt-0.5" />}
                {revealed && isSelected && !isAnswer && <XCircle size={16} className="text-red-400 shrink-0 mt-0.5" />}
              </button>
            );
          })}
        </div>

        {/* AI Correction panel */}
        {revealed && !isCorrect && (
          <div className="mb-5 bg-[#0f1629] border border-[#1e2d50] rounded-2xl overflow-hidden">
            <div className="flex items-center gap-2 px-5 py-3 border-b border-[#1a2240] bg-[#1a2240]/50">
              <Sparkles size={14} className="text-yellow-400" />
              <span className="text-sm font-semibold text-white">Correção Inteligente</span>
              {aiLoading && <Loader2 size={12} className="text-[#64748b] spin-slow ml-auto" />}
            </div>

            {aiLoading ? (
              <div className="px-5 py-6 text-center text-[#64748b] text-sm">
                Gerando correção com IA...
              </div>
            ) : aiResult ? (
              <div className="p-5 space-y-4">
                <div>
                  <p className="text-xs font-semibold text-red-400 uppercase tracking-wider mb-1.5">❌ Por que está errado</p>
                  <p className="text-sm text-[#94a3b8] leading-relaxed">{aiResult.explanation}</p>
                </div>
                <div className="border-t border-[#1a2240] pt-4">
                  <p className="text-xs font-semibold text-green-400 uppercase tracking-wider mb-1.5">✅ Como resolver</p>
                  <p className="text-sm text-[#94a3b8] leading-relaxed whitespace-pre-line">{aiResult.howToSolve}</p>
                </div>
                <div className="border-t border-[#1a2240] pt-4">
                  <p className="text-xs font-semibold text-yellow-400 uppercase tracking-wider mb-1.5">💡 Dica para a próxima</p>
                  <p className="text-sm text-[#94a3b8] leading-relaxed">{aiResult.tip}</p>
                </div>
              </div>
            ) : (
              <div className="px-5 py-4">
                <p className="text-xs font-semibold text-green-400 uppercase tracking-wider mb-1.5">✅ Gabarito e Solução</p>
                <p className="text-sm text-[#94a3b8] leading-relaxed">{current.solution}</p>
              </div>
            )}
          </div>
        )}

        {revealed && isCorrect && (
          <div className="mb-5 bg-green-500/10 border border-green-500/20 rounded-2xl p-4">
            <p className="text-green-400 font-semibold text-sm flex items-center gap-2">
              <CheckCircle2 size={15} /> Correto! {current.solution.slice(0, 100)}...
            </p>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex gap-3">
          {!revealed ? (
            <button
              onClick={handleReveal}
              disabled={!selected}
              className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors"
            >
              Confirmar resposta
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              {state.currentIndex + 1 < state.questions.length ? 'Próxima questão' : 'Ver resultado'}
              <ChevronRight size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
