import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { getAnswers, type AnswerRecord } from "../lib/store";
import { SUBJECTS, YEARS } from "../data/questions";

type Props = { user: User };

const SUBJECT_COLORS: Record<string, string> = {
  blue: "#60a5fa", purple: "#c084fc", green: "#4ade80", amber: "#fbbf24"
};
const DIFF_COLORS: Record<string, string> = {
  facil: "#4ade80", medio: "#fbbf24", dificil: "#f87171"
};

export default function Desempenho({ user }: Props) {
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAnswers(user.id).then((a) => { setAnswers(a); setLoading(false); });
  }, [user.id]);

  if (loading) return <div className="flex items-center justify-center h-96 text-sm opacity-40">Carregando...</div>;

  const total = answers.length;
  const correct = answers.filter((a) => a.correct).length;
  const rate = total ? Math.round((correct / total) * 100) : 0;

  const subjectStats = SUBJECTS.map((s) => {
    const sub = answers.filter((a) => a.subject === s.id);
    const c = sub.filter((a) => a.correct).length;
    return { ...s, total: sub.length, correct: c, rate: sub.length ? Math.round((c / sub.length) * 100) : 0 };
  });

  const yearStats = YEARS.map((y) => {
    const yr = answers.filter((a) => a.year === y);
    const c = yr.filter((a) => a.correct).length;
    return { year: y, total: yr.length, correct: c, rate: yr.length ? Math.round((c / yr.length) * 100) : 0 };
  }).filter((y) => y.total > 0);

  const diffStats = ["facil", "medio", "dificil"].map((d) => {
    const diff = answers.filter((a) => a.difficulty === d);
    const c = diff.filter((a) => a.correct).length;
    return { diff: d, total: diff.length, correct: c, rate: diff.length ? Math.round((c / diff.length) * 100) : 0 };
  });

  // Topic analysis
  const topicMap: Record<string, { correct: number; total: number }> = {};
  answers.forEach((a) => {
    if (!topicMap[a.topic]) topicMap[a.topic] = { correct: 0, total: 0 };
    topicMap[a.topic].total++;
    if (a.correct) topicMap[a.topic].correct++;
  });
  const topics = Object.entries(topicMap)
    .map(([topic, v]) => ({ topic, ...v, rate: Math.round((v.correct / v.total) * 100) }))
    .sort((a, b) => a.rate - b.rate)
    .slice(0, 8);

  // Weekly progress (last 7 days)
  const now = Date.now();
  const recent = answers.filter(() => true).slice(-50);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-8">
        <div className="text-xs tracking-[0.3em] uppercase opacity-30 mb-1">Análise</div>
        <h1 className="text-2xl font-bold" style={{ color: "#c8b97a" }}>Desempenho</h1>
      </div>

      {total === 0 ? (
        <div className="text-center py-20 opacity-40">
          <div className="text-5xl mb-4">◈</div>
          <div className="text-sm">Nenhuma questão respondida ainda.</div>
          <div className="text-xs mt-1 opacity-60">Faça um treino ou simulado para ver seus dados aqui.</div>
        </div>
      ) : (
        <>
          {/* Summary */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            {[
              { label: "Total respondidas", value: total, unit: "" },
              { label: "Acertos", value: correct, unit: "" },
              { label: "Taxa geral", value: rate, unit: "%" },
            ].map((s) => (
              <div key={s.label} className="rounded-xl p-5 border border-white/8 text-center" style={{ background: "#0d0f1a" }}>
                <div className="text-3xl font-black mb-1" style={{ color: "#c8b97a" }}>{s.value}{s.unit}</div>
                <div className="text-xs opacity-40">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Subject breakdown */}
          <div className="rounded-xl border border-white/8 mb-6" style={{ background: "#0d0f1a" }}>
            <div className="px-5 py-4 border-b border-white/8">
              <div className="text-xs tracking-widest uppercase opacity-40">Por Matéria</div>
            </div>
            <div className="p-5 space-y-4">
              {subjectStats.filter((s) => s.total > 0).map((s) => (
                <div key={s.id}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span style={{ color: SUBJECT_COLORS[s.color] }}>{s.icon}</span>
                      <span className="text-sm">{s.label}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold" style={{ color: SUBJECT_COLORS[s.color] }}>{s.rate}%</span>
                      <span className="text-xs opacity-30 ml-2">{s.correct}/{s.total}</span>
                    </div>
                  </div>
                  <div className="h-2 rounded-full bg-white/5">
                    <div className="h-full rounded-full transition-all" style={{ width: `${s.rate}%`, background: SUBJECT_COLORS[s.color] }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Difficulty breakdown */}
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div className="rounded-xl border border-white/8" style={{ background: "#0d0f1a" }}>
              <div className="px-5 py-4 border-b border-white/8">
                <div className="text-xs tracking-widest uppercase opacity-40">Por Dificuldade</div>
              </div>
              <div className="p-5 space-y-4">
                {diffStats.filter((d) => d.total > 0).map((d) => (
                  <div key={d.diff}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm capitalize">{d.diff}</span>
                      <span className="text-sm font-bold" style={{ color: DIFF_COLORS[d.diff] }}>{d.rate}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/5">
                      <div className="h-full rounded-full" style={{ width: `${d.rate}%`, background: DIFF_COLORS[d.diff] }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* By year */}
            <div className="rounded-xl border border-white/8" style={{ background: "#0d0f1a" }}>
              <div className="px-5 py-4 border-b border-white/8">
                <div className="text-xs tracking-widest uppercase opacity-40">Por Ano</div>
              </div>
              <div className="p-5 space-y-3">
                {yearStats.map((y) => (
                  <div key={y.year} className="flex items-center gap-3">
                    <span className="text-xs w-10 opacity-50">{y.year}</span>
                    <div className="flex-1 h-1.5 rounded-full bg-white/5">
                      <div className="h-full rounded-full bg-amber-400/60" style={{ width: `${y.rate}%` }} />
                    </div>
                    <span className="text-xs font-bold w-10 text-right opacity-70">{y.rate}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Weak topics */}
          {topics.length > 0 && (
            <div className="rounded-xl border border-white/8" style={{ background: "#0d0f1a" }}>
              <div className="px-5 py-4 border-b border-white/8">
                <div className="text-xs tracking-widest uppercase opacity-40">Tópicos para Reforçar</div>
              </div>
              <div className="p-5">
                <div className="space-y-2">
                  {topics.map((t) => (
                    <div key={t.topic} className="flex items-center gap-3 py-1.5 border-b border-white/5 last:border-0">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black"
                        style={{
                          background: t.rate < 40 ? "rgba(248,113,113,0.12)" : t.rate < 70 ? "rgba(251,191,36,0.12)" : "rgba(74,222,128,0.12)",
                          color: t.rate < 40 ? "#f87171" : t.rate < 70 ? "#fbbf24" : "#4ade80",
                        }}
                      >
                        {t.rate}%
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm truncate">{t.topic}</div>
                        <div className="text-xs opacity-30">{t.correct}/{t.total} acertos</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
