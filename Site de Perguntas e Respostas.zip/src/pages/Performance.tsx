import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { kvGet } from '../lib/api';
import Navbar from '../components/Navbar';
import { SUBJECTS } from '../data/questions';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, Cell
} from 'recharts';
import { TrendingUp, Trophy, Target, Zap } from 'lucide-react';

interface SessionResult {
  id: string;
  subject: string;
  score: number;
  total: number;
  date: string;
  mode: string;
}

export default function Performance() {
  const [sessions, setSessions] = useState<SessionResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      const sessionData = await kvGet(`user:${data.user.id}:sessions`);
      setSessions(Array.isArray(sessionData) ? sessionData : []);
      setLoading(false);
    };
    load();
  }, []);

  const totalQuestions = sessions.reduce((a, s) => a + s.total, 0);
  const totalCorrect = sessions.reduce((a, s) => a + s.score, 0);
  const overallPct = totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;
  const streak = sessions.length;

  const subjectStats = SUBJECTS.map(sub => {
    const subs = sessions.filter(s => s.subject === sub.id || s.subject === 'all');
    const total = subs.reduce((a, s) => a + s.total, 0);
    const correct = subs.reduce((a, s) => a + s.score, 0);
    const acc = total > 0 ? Math.round((correct / total) * 100) : 0;
    return { subject: sub.label, accuracy: acc, color: sub.color, emoji: sub.emoji };
  });

  // Timeline data (last 10 sessions)
  const timelineData = sessions.slice(-10).map((s, i) => ({
    name: `S${i + 1}`,
    acerto: Math.round((s.score / s.total) * 100),
    date: new Date(s.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
  }));

  // Subject bar data
  const barData = SUBJECTS.map(sub => {
    const subs = sessions.filter(s => s.subject === sub.id);
    const total = subs.reduce((a, s) => a + s.total, 0);
    const correct = subs.reduce((a, s) => a + s.score, 0);
    return {
      name: sub.label.slice(0, 4),
      acertos: correct,
      total,
      pct: total > 0 ? Math.round((correct / total) * 100) : 0,
      color: sub.color,
    };
  });

  const radarData = SUBJECTS.map(sub => {
    const subs = sessions.filter(s => s.subject === sub.id);
    const total = subs.reduce((a, s) => a + s.total, 0);
    const correct = subs.reduce((a, s) => a + s.score, 0);
    return { subject: sub.label, value: total > 0 ? Math.round((correct / total) * 100) : 0 };
  });

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-[#0f1629] border border-[#1e2d50] rounded-lg p-2.5 text-xs">
        <p className="text-white font-semibold">{payload[0].value}%</p>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#080d1a]">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-white mb-1">Desempenho</h1>
          <p className="text-[#64748b]">Sua evolução ao longo do tempo</p>
        </div>

        {loading ? (
          <div className="text-center py-16 text-[#64748b]">Carregando dados...</div>
        ) : sessions.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-4xl mb-4">📊</div>
            <p className="text-white font-semibold mb-2">Nenhum dado ainda</p>
            <p className="text-[#64748b] text-sm">Complete algumas questões para ver seu desempenho</p>
          </div>
        ) : (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
              {[
                { icon: Target, label: 'Total de questões', value: totalQuestions, color: 'text-blue-400', bg: 'bg-blue-500/10' },
                { icon: Trophy, label: 'Total de acertos', value: totalCorrect, color: 'text-green-400', bg: 'bg-green-500/10' },
                { icon: Zap, label: 'Taxa geral', value: `${overallPct}%`, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
                { icon: TrendingUp, label: 'Sessões', value: streak, color: 'text-purple-400', bg: 'bg-purple-500/10' },
              ].map(({ icon: Icon, label, value, color, bg }) => (
                <div key={label} className="bg-[#0f1629] border border-[#1e2d50] rounded-xl p-4">
                  <div className={`w-8 h-8 rounded-lg ${bg} flex items-center justify-center mb-3`}>
                    <Icon size={16} className={color} />
                  </div>
                  <p className="text-2xl font-bold text-white font-display">{value}</p>
                  <p className="text-[#64748b] text-xs mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              {/* Timeline */}
              <div className="bg-[#0f1629] border border-[#1e2d50] rounded-xl p-5">
                <h2 className="font-display font-bold text-white mb-4">Evolução do acerto (%)</h2>
                {timelineData.length > 1 ? (
                  <ResponsiveContainer width="100%" height={180}>
                    <LineChart data={timelineData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e2d50" />
                      <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 10 }} />
                      <YAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 10 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="acerto" stroke="#3b82f6" strokeWidth={2} dot={{ fill: '#3b82f6', r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-[#64748b] text-sm text-center py-8">Complete mais sessões para ver o gráfico</p>
                )}
              </div>

              {/* Radar */}
              <div className="bg-[#0f1629] border border-[#1e2d50] rounded-xl p-5">
                <h2 className="font-display font-bold text-white mb-4">Perfil por matéria</h2>
                <ResponsiveContainer width="100%" height={180}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="#1e2d50" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 10 }} />
                    <Radar dataKey="value" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Bar chart */}
            <div className="bg-[#0f1629] border border-[#1e2d50] rounded-xl p-5 mb-4">
              <h2 className="font-display font-bold text-white mb-4">Acertos por matéria</h2>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={barData} barSize={32}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e2d50" />
                  <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 10 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="pct" radius={[4, 4, 0, 0]}>
                    {barData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Subject breakdown */}
            <div className="bg-[#0f1629] border border-[#1e2d50] rounded-xl p-5">
              <h2 className="font-display font-bold text-white mb-4">Detalhamento por matéria</h2>
              <div className="space-y-4">
                {subjectStats.map(s => (
                  <div key={s.subject}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm text-white flex items-center gap-2">
                        <span>{s.emoji}</span> {s.subject}
                      </span>
                      <span className="text-sm font-bold" style={{ color: s.accuracy >= 70 ? '#10b981' : s.accuracy >= 50 ? '#f59e0b' : '#ef4444' }}>
                        {s.accuracy}%
                      </span>
                    </div>
                    <div className="h-2 bg-[#1a2240] rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${s.accuracy}%`, backgroundColor: s.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent sessions list */}
            <div className="mt-4 bg-[#0f1629] border border-[#1e2d50] rounded-xl p-5">
              <h2 className="font-display font-bold text-white mb-4">Histórico de sessões</h2>
              <div className="space-y-2">
                {sessions.slice().reverse().slice(0, 15).map(s => {
                  const sub = SUBJECTS.find(x => x.id === s.subject);
                  const pct = Math.round((s.score / s.total) * 100);
                  return (
                    <div key={s.id} className="flex items-center gap-3 py-2.5 border-b border-[#1a2240] last:border-0">
                      <span className="text-lg">{sub?.emoji || '📝'}</span>
                      <div className="flex-1">
                        <p className="text-sm text-white">{sub?.label || 'Simulado completo'}</p>
                        <p className="text-xs text-[#64748b]">
                          {new Date(s.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' })}
                          {' · '}{s.mode === 'simulation' ? 'Simulado' : 'Treino'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold" style={{ color: pct >= 70 ? '#10b981' : pct >= 50 ? '#f59e0b' : '#ef4444' }}>
                          {pct}%
                        </p>
                        <p className="text-xs text-[#64748b]">{s.score}/{s.total}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
