import { supabase } from "./supabase";

export type AnswerRecord = {
  questionId: string;
  userAnswer: string;
  correct: boolean;
  subject: string;
  year: number;
  difficulty: string;
  topic: string;
};

export type SimuladoState = {
  id: string;
  userId: string;
  name: string;
  questions: string[];
  answers: Record<string, string>;
  currentIndex: number;
  startedAt: string;
  pausedAt?: string;
  completedAt?: string;
  timeElapsedSeconds: number;
  subjects: string[];
  years: number[];
};

const TABLE = "kv_store_bfdc3feb";

async function kvGet(key: string): Promise<unknown> {
  const { data } = await supabase.from(TABLE).select("value").eq("key", key).maybeSingle();
  return data?.value ?? null;
}

async function kvSet(key: string, value: unknown): Promise<void> {
  await supabase.from(TABLE).upsert({ key, value });
}

async function kvDel(key: string): Promise<void> {
  await supabase.from(TABLE).delete().eq("key", key);
}

async function kvGetByPrefix(prefix: string): Promise<{ key: string; value: unknown }[]> {
  const { data } = await supabase.from(TABLE).select("key, value").like("key", `${prefix}%`);
  return data ?? [];
}

export async function saveAnswer(userId: string, record: AnswerRecord) {
  const key = `answers:${userId}`;
  const existing = (await kvGet(key) as AnswerRecord[] | null) ?? [];
  existing.push(record);
  await kvSet(key, existing);
}

export async function getAnswers(userId: string): Promise<AnswerRecord[]> {
  return ((await kvGet(`answers:${userId}`)) as AnswerRecord[] | null) ?? [];
}

export async function saveSimulado(sim: SimuladoState) {
  await kvSet(`simulado:${sim.userId}:${sim.id}`, sim);
}

export async function getSimulados(userId: string): Promise<SimuladoState[]> {
  const rows = await kvGetByPrefix(`simulado:${userId}:`);
  return rows.map((r) => r.value as SimuladoState).filter(Boolean);
}

export async function deleteSimulado(userId: string, simId: string) {
  await kvDel(`simulado:${userId}:${simId}`);
}
