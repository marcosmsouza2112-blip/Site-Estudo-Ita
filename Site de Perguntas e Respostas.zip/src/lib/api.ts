import { projectId } from "../../utils/supabase/info";

const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-bfdc3feb`;

export async function getAIExplanation(opts: {
  question: string;
  correctAnswer: string;
  userAnswer: string;
  subject: string;
  topic: string;
  explanation: string;
}): Promise<string> {
  try {
    const res = await fetch(`${BASE}/ai-explain`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(opts),
    });
    if (!res.ok) throw new Error("API error");
    const data = await res.json();
    return data.explanation as string;
  } catch {
    return generateFallbackExplanation(opts);
  }
}

function generateFallbackExplanation(opts: {
  correctAnswer: string;
  userAnswer: string;
  subject: string;
  topic: string;
  explanation: string;
}): string {
  return `**Por que você errou:**\nVocê marcou a alternativa **${opts.userAnswer}**, mas a correta é **${opts.correctAnswer}**.

**Resolução:**\n${opts.explanation}

**Como melhorar:**\nReforce seus estudos no tópico de **${opts.topic}** em **${opts.subject}**. Revise os conceitos fundamentais e pratique questões similares.`;
}
