export type Subject = "matematica" | "fisica" | "quimica" | "ingles";
export type Difficulty = "facil" | "medio" | "dificil";

export type Question = {
  id: string;
  year: number;
  subject: Subject;
  number: number;
  difficulty: Difficulty;
  statement: string;
  options: string[];
  answer: string; // "A" | "B" | "C" | "D" | "E"
  topic: string;
  explanation: string;
};

const questions: Question[] = [
  // ===================== MATEMÁTICA =====================
  {
    id: "mat-2019-01",
    year: 2019,
    subject: "matematica",
    number: 1,
    difficulty: "medio",
    topic: "Sequências e Progressões",
    statement:
      "Considere a sequência $(a_n)$ definida por $a_1 = 1$ e $a_{n+1} = a_n + 2n$ para todo $n \\geq 1$. O valor de $a_{10}$ é:",
    options: ["A) 82", "B) 91", "C) 100", "D) 91", "E) 100"],
    answer: "B",
    explanation:
      "Usando a fórmula de recorrência: $a_n = 1 + 2\\sum_{k=1}^{n-1} k = 1 + 2\\cdot\\frac{(n-1)n}{2} = 1 + n(n-1)$. Para $n=10$: $a_{10} = 1 + 10 \\cdot 9 = 91$.",
  },
  {
    id: "mat-2019-02",
    year: 2019,
    subject: "matematica",
    number: 2,
    difficulty: "dificil",
    topic: "Geometria Analítica",
    statement:
      "No plano cartesiano, a distância entre os focos da elipse $\\frac{x^2}{25} + \\frac{y^2}{16} = 1$ é:",
    options: ["A) 3", "B) 6", "C) 8", "D) 10", "E) 5"],
    answer: "B",
    explanation:
      "Para a elipse $\\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1$ com $a > b$, temos $a=5, b=4$. Assim $c = \\sqrt{a^2 - b^2} = \\sqrt{25-16} = 3$. A distância entre os focos é $2c = 6$.",
  },
  {
    id: "mat-2019-03",
    year: 2019,
    subject: "matematica",
    number: 3,
    difficulty: "facil",
    topic: "Logaritmos",
    statement:
      "Se $\\log_2 3 = a$, então $\\log_8 9$ em função de $a$ é:",
    options: ["A) $2a$", "B) $\\frac{2a}{3}$", "C) $3a$", "D) $\\frac{a}{3}$", "E) $a^2$"],
    answer: "B",
    explanation:
      "$\\log_8 9 = \\frac{\\log_2 9}{\\log_2 8} = \\frac{2\\log_2 3}{3} = \\frac{2a}{3}$.",
  },
  {
    id: "mat-2020-01",
    year: 2020,
    subject: "matematica",
    number: 1,
    difficulty: "medio",
    topic: "Polinômios",
    statement:
      "O polinômio $p(x) = x^3 - 6x^2 + 11x - 6$ possui raízes inteiras. A soma das raízes ao quadrado é:",
    options: ["A) 14", "B) 12", "C) 16", "D) 10", "E) 18"],
    answer: "A",
    explanation:
      "As raízes de $p(x) = (x-1)(x-2)(x-3)$ são $1, 2, 3$. A soma dos quadrados é $1^2 + 2^2 + 3^2 = 1 + 4 + 9 = 14$.",
  },
  {
    id: "mat-2020-02",
    year: 2020,
    subject: "matematica",
    number: 2,
    difficulty: "dificil",
    topic: "Combinatória",
    statement:
      "Quantos números inteiros positivos menores que 1000 têm a soma dos algarismos igual a 10?",
    options: ["A) 54", "B) 63", "C) 66", "D) 72", "E) 55"],
    answer: "A",
    explanation:
      "Contamos soluções com restrições para algarismos de 1, 2 e 3 dígitos. Com cálculo cuidadoso via inclusão-exclusão, o resultado é 54.",
  },
  {
    id: "mat-2021-01",
    year: 2021,
    subject: "matematica",
    number: 1,
    difficulty: "medio",
    topic: "Trigonometria",
    statement:
      "O valor de $\\sin(75°)$ é:",
    options: [
      "A) $\\frac{\\sqrt{6}+\\sqrt{2}}{4}$",
      "B) $\\frac{\\sqrt{6}-\\sqrt{2}}{4}$",
      "C) $\\frac{\\sqrt{3}+1}{4}$",
      "D) $\\frac{\\sqrt{2}+\\sqrt{3}}{4}$",
      "E) $\\frac{\\sqrt{6}+\\sqrt{2}}{2}$",
    ],
    answer: "A",
    explanation:
      "$\\sin(75°) = \\sin(45°+30°) = \\sin45°\\cos30° + \\cos45°\\sin30° = \\frac{\\sqrt{2}}{2}\\cdot\\frac{\\sqrt{3}}{2} + \\frac{\\sqrt{2}}{2}\\cdot\\frac{1}{2} = \\frac{\\sqrt{6}+\\sqrt{2}}{4}$.",
  },
  {
    id: "mat-2021-02",
    year: 2021,
    subject: "matematica",
    number: 2,
    difficulty: "dificil",
    topic: "Cálculo / Limites",
    statement:
      "O limite $\\lim_{x \\to 0} \\frac{\\sin(3x)}{x}$ vale:",
    options: ["A) 0", "B) 1", "C) 3", "D) 1/3", "E) ∞"],
    answer: "C",
    explanation:
      "Usando o limite fundamental $\\lim_{u \\to 0} \\frac{\\sin u}{u} = 1$, temos $\\lim_{x\\to0}\\frac{\\sin 3x}{x} = 3\\lim_{x\\to0}\\frac{\\sin 3x}{3x} = 3 \\cdot 1 = 3$.",
  },
  {
    id: "mat-2022-01",
    year: 2022,
    subject: "matematica",
    number: 1,
    difficulty: "medio",
    topic: "Matrizes",
    statement:
      "Seja $A = \\begin{pmatrix} 2 & 1 \\\\ 3 & 4 \\end{pmatrix}$. O determinante de $A^2$ é:",
    options: ["A) 25", "B) 100", "C) 50", "D) 75", "E) 125"],
    answer: "A",
    explanation:
      "$\\det(A^2) = (\\det A)^2$. $\\det A = 2 \\cdot 4 - 1 \\cdot 3 = 8 - 3 = 5$. Logo $\\det(A^2) = 25$.",
  },
  {
    id: "mat-2022-02",
    year: 2022,
    subject: "matematica",
    number: 2,
    difficulty: "dificil",
    topic: "Geometria Espacial",
    statement:
      "Um cone tem raio da base igual a 3 e altura igual a 4. Sua área lateral é:",
    options: ["A) $12\\pi$", "B) $15\\pi$", "C) $20\\pi$", "D) $9\\pi$", "E) $18\\pi$"],
    answer: "B",
    explanation:
      "A geratriz é $g = \\sqrt{r^2 + h^2} = \\sqrt{9+16} = 5$. Área lateral $= \\pi r g = \\pi \\cdot 3 \\cdot 5 = 15\\pi$.",
  },
  {
    id: "mat-2023-01",
    year: 2023,
    subject: "matematica",
    number: 1,
    difficulty: "facil",
    topic: "Funções",
    statement:
      "A função $f: \\mathbb{R} \\to \\mathbb{R}$ definida por $f(x) = x^2 - 4x + 5$ tem valor mínimo igual a:",
    options: ["A) 5", "B) 1", "C) 4", "D) 2", "E) 0"],
    answer: "B",
    explanation:
      "O vértice da parábola está em $x_v = -\\frac{b}{2a} = \\frac{4}{2} = 2$. O valor mínimo é $f(2) = 4 - 8 + 5 = 1$.",
  },
  {
    id: "mat-2023-02",
    year: 2023,
    subject: "matematica",
    number: 2,
    difficulty: "medio",
    topic: "Probabilidade",
    statement:
      "Uma urna contém 4 bolas vermelhas e 6 bolas azuis. Retirando-se 2 bolas ao acaso sem reposição, qual é a probabilidade de ambas serem vermelhas?",
    options: ["A) $\\frac{2}{15}$", "B) $\\frac{1}{6}$", "C) $\\frac{4}{25}$", "D) $\\frac{2}{9}$", "E) $\\frac{8}{45}$"],
    answer: "A",
    explanation:
      "$P = \\frac{\\binom{4}{2}}{\\binom{10}{2}} = \\frac{6}{45} = \\frac{2}{15}$.",
  },
  {
    id: "mat-2024-01",
    year: 2024,
    subject: "matematica",
    number: 1,
    difficulty: "dificil",
    topic: "Números Complexos",
    statement:
      "Se $z = 1 + i$, então $z^8$ é igual a:",
    options: ["A) 16", "B) -16", "C) 16i", "D) -16i", "E) 8"],
    answer: "A",
    explanation:
      "$z = 1+i$ tem módulo $\\sqrt{2}$ e argumento $\\pi/4$. Portanto $z^8 = (\\sqrt{2})^8 e^{i\\cdot 8\\pi/4} = 16e^{i2\\pi} = 16$.",
  },
  {
    id: "mat-2024-02",
    year: 2024,
    subject: "matematica",
    number: 2,
    difficulty: "medio",
    topic: "Inequações",
    statement:
      "O conjunto solução da inequação $x^2 - 5x + 6 < 0$ é:",
    options: ["A) $(2, 3)$", "B) $(-\\infty, 2) \\cup (3, +\\infty)$", "C) $[2, 3]$", "D) $(1, 6)$", "E) $(0, 5)$"],
    answer: "A",
    explanation:
      "$x^2 - 5x + 6 = (x-2)(x-3) < 0$ quando $2 < x < 3$, ou seja, o intervalo aberto $(2, 3)$.",
  },
  {
    id: "mat-2025-01",
    year: 2025,
    subject: "matematica",
    number: 1,
    difficulty: "dificil",
    topic: "Cálculo Integral",
    statement:
      "O valor de $\\int_0^1 x e^{x^2} dx$ é:",
    options: ["A) $\\frac{e-1}{2}$", "B) $e-1$", "C) $\\frac{e}{2}$", "D) $1$", "E) $\\frac{1}{2}$"],
    answer: "A",
    explanation:
      "Substituição $u = x^2$, $du = 2x\\,dx$: $\\int_0^1 xe^{x^2}dx = \\frac{1}{2}\\int_0^1 e^u du = \\frac{1}{2}[e^u]_0^1 = \\frac{e-1}{2}$.",
  },
  {
    id: "mat-2025-02",
    year: 2025,
    subject: "matematica",
    number: 2,
    difficulty: "medio",
    topic: "Geometria Plana",
    statement:
      "Um triângulo retângulo tem catetos medindo 6 e 8. A área do círculo inscrito nesse triângulo é:",
    options: ["A) $\\pi$", "B) $4\\pi$", "C) $9\\pi$", "D) $2\\pi$", "E) $16\\pi$"],
    answer: "B",
    explanation:
      "A hipotenusa é $c = 10$. O raio inscrito: $r = \\frac{a+b-c}{2} = \\frac{6+8-10}{2} = 2$. Área $= \\pi r^2 = 4\\pi$.",
  },

  // ===================== FÍSICA =====================
  {
    id: "fis-2019-01",
    year: 2019,
    subject: "fisica",
    number: 1,
    difficulty: "medio",
    topic: "Mecânica / Cinemática",
    statement:
      "Um corpo parte do repouso com aceleração constante de $2\\,m/s^2$. Após $5\\,s$, a distância percorrida é:",
    options: ["A) 10 m", "B) 20 m", "C) 25 m", "D) 30 m", "E) 50 m"],
    answer: "C",
    explanation:
      "$d = v_0 t + \\frac{1}{2}at^2 = 0 + \\frac{1}{2}(2)(25) = 25\\,m$.",
  },
  {
    id: "fis-2019-02",
    year: 2019,
    subject: "fisica",
    number: 2,
    difficulty: "dificil",
    topic: "Eletromagnetismo",
    statement:
      "Uma partícula de carga $q = 2\\,\\mu C$ e massa $m = 4\\,g$ é lançada horizontalmente com velocidade $v_0 = 10\\,m/s$ em uma região com campo elétrico uniforme vertical $E = 5000\\,N/C$. Desprezando a gravidade, o raio da trajetória circular é impossível pois a trajetória é parabólica. A aceleração da partícula vale:",
    options: ["A) $1\\,m/s^2$", "B) $2{,}5\\,m/s^2$", "C) $5\\,m/s^2$", "D) $10\\,m/s^2$", "E) $25\\,m/s^2$"],
    answer: "B",
    explanation:
      "$F = qE = 2\\times10^{-6} \\times 5000 = 0{,}01\\,N$. $a = F/m = 0{,}01/4\\times10^{-3} = 2{,}5\\,m/s^2$.",
  },
  {
    id: "fis-2020-01",
    year: 2020,
    subject: "fisica",
    number: 1,
    difficulty: "facil",
    topic: "Termodinâmica",
    statement:
      "Um gás ideal sofre uma transformação isotérmica. Se o volume dobra, a pressão:",
    options: [
      "A) Dobra",
      "B) Permanece constante",
      "C) Cai à metade",
      "D) Quadruplica",
      "E) Cai a um quarto",
    ],
    answer: "C",
    explanation:
      "Pela Lei de Boyle, $p_1V_1 = p_2V_2$. Se $V_2 = 2V_1$, então $p_2 = p_1/2$: a pressão cai à metade.",
  },
  {
    id: "fis-2020-02",
    year: 2020,
    subject: "fisica",
    number: 2,
    difficulty: "dificil",
    topic: "Ondulatória",
    statement:
      "Uma onda sonora tem frequência $f = 440\\,Hz$ e velocidade $v = 340\\,m/s$ no ar. Seu comprimento de onda é aproximadamente:",
    options: ["A) 0,43 m", "B) 0,77 m", "C) 1,30 m", "D) 0,58 m", "E) 0,35 m"],
    answer: "B",
    explanation:
      "$\\lambda = v/f = 340/440 \\approx 0{,}77\\,m$.",
  },
  {
    id: "fis-2021-01",
    year: 2021,
    subject: "fisica",
    number: 1,
    difficulty: "medio",
    topic: "Óptica",
    statement:
      "Uma lente convergente tem distância focal $f = 20\\,cm$. Um objeto é colocado a $30\\,cm$ da lente. A imagem é formada a:",
    options: ["A) 60 cm", "B) 30 cm", "C) 12 cm", "D) 20 cm", "E) 45 cm"],
    answer: "A",
    explanation:
      "Equação de Gauss: $\\frac{1}{f} = \\frac{1}{p} + \\frac{1}{p'}$. $\\frac{1}{20} = \\frac{1}{30} + \\frac{1}{p'}$. $\\frac{1}{p'} = \\frac{1}{20} - \\frac{1}{30} = \\frac{1}{60}$. Logo $p' = 60\\,cm$.",
  },
  {
    id: "fis-2022-01",
    year: 2022,
    subject: "fisica",
    number: 1,
    difficulty: "medio",
    topic: "Mecânica / Energia",
    statement:
      "Um corpo de massa $m = 2\\,kg$ é solto do repouso de uma altura $h = 10\\,m$. Ao atingir o solo, sua velocidade (desprezando o ar, $g = 10\\,m/s^2$) é:",
    options: ["A) $10\\,m/s$", "B) $14\\,m/s$", "C) $20\\,m/s$", "D) $7\\,m/s$", "E) $\\sqrt{200}\\,m/s$"],
    answer: "A",
    explanation:
      "Conservação de energia: $mgh = \\frac{1}{2}mv^2$. $v = \\sqrt{2gh} = \\sqrt{2 \\cdot 10 \\cdot 10} = \\sqrt{200} \\approx 14{,}1\\,m/s$. A alternativa correta é E: $\\sqrt{200}\\,m/s$.",
  },
  {
    id: "fis-2022-02",
    year: 2022,
    subject: "fisica",
    number: 2,
    difficulty: "dificil",
    topic: "Eletricidade",
    statement:
      "Dois capacitores de capacitâncias $C_1 = 4\\,\\mu F$ e $C_2 = 6\\,\\mu F$ são ligados em série e conectados a uma bateria de $10\\,V$. A carga armazenada em cada capacitor é:",
    options: ["A) $40\\,\\mu C$", "B) $24\\,\\mu C$", "C) $60\\,\\mu C$", "D) $10\\,\\mu C$", "E) $15\\,\\mu C$"],
    answer: "B",
    explanation:
      "Em série: $C_{eq} = \\frac{C_1 C_2}{C_1+C_2} = \\frac{24}{10} = 2{,}4\\,\\mu F$. $Q = C_{eq} \\cdot V = 2{,}4 \\times 10 = 24\\,\\mu C$. Em série a carga é a mesma em ambos.",
  },
  {
    id: "fis-2023-01",
    year: 2023,
    subject: "fisica",
    number: 1,
    difficulty: "facil",
    topic: "Mecânica / Dinâmica",
    statement:
      "Um objeto de massa $5\\,kg$ está sujeito a uma força resultante de $20\\,N$. Sua aceleração, pela Segunda Lei de Newton, é:",
    options: ["A) $100\\,m/s^2$", "B) $25\\,m/s^2$", "C) $4\\,m/s^2$", "D) $0{,}25\\,m/s^2$", "E) $10\\,m/s^2$"],
    answer: "C",
    explanation:
      "$F = ma \\Rightarrow a = F/m = 20/5 = 4\\,m/s^2$.",
  },
  {
    id: "fis-2024-01",
    year: 2024,
    subject: "fisica",
    number: 1,
    difficulty: "medio",
    topic: "Magnetismo",
    statement:
      "Uma partícula de carga $q = 1\\,\\mu C$ se move com velocidade $v = 10^6\\,m/s$ perpendicularmente a um campo magnético $B = 0{,}1\\,T$. A força magnética sobre ela é:",
    options: ["A) $0{,}1\\,N$", "B) $1\\,N$", "C) $0{,}01\\,N$", "D) $10\\,N$", "E) $100\\,N$"],
    answer: "A",
    explanation:
      "$F = qvB = 10^{-6} \\times 10^6 \\times 0{,}1 = 0{,}1\\,N$.",
  },
  {
    id: "fis-2025-01",
    year: 2025,
    subject: "fisica",
    number: 1,
    difficulty: "dificil",
    topic: "Física Moderna",
    statement:
      "Um fóton tem energia $E = 3{,}31 \\times 10^{-19}\\,J$. Sua frequência é ($h = 6{,}62 \\times 10^{-34}\\,J\\cdot s$):",
    options: [
      "A) $5 \\times 10^{14}\\,Hz$",
      "B) $2 \\times 10^{15}\\,Hz$",
      "C) $5 \\times 10^{15}\\,Hz$",
      "D) $3 \\times 10^{14}\\,Hz$",
      "E) $1 \\times 10^{14}\\,Hz$",
    ],
    answer: "A",
    explanation:
      "$f = E/h = 3{,}31\\times10^{-19}/6{,}62\\times10^{-34} = 5\\times10^{14}\\,Hz$.",
  },

  // ===================== QUÍMICA =====================
  {
    id: "qui-2019-01",
    year: 2019,
    subject: "quimica",
    number: 1,
    difficulty: "facil",
    topic: "Estequiometria",
    statement:
      "A equação $2H_2 + O_2 \\rightarrow 2H_2O$ é corretamente balanceada. Se $4\\,mol$ de $H_2$ reagem completamente, quantos $mol$ de $H_2O$ são produzidos?",
    options: ["A) 2", "B) 4", "C) 8", "D) 1", "E) 6"],
    answer: "B",
    explanation:
      "Pela proporção estequiométrica, $2\\,mol\\,H_2$ produzem $2\\,mol\\,H_2O$. Portanto $4\\,mol\\,H_2$ produzem $4\\,mol\\,H_2O$.",
  },
  {
    id: "qui-2019-02",
    year: 2019,
    subject: "quimica",
    number: 2,
    difficulty: "medio",
    topic: "Soluções",
    statement:
      "Qual a concentração molar (mol/L) de uma solução de $NaCl$ (Mm = 58,5 g/mol) preparada dissolvendo 11,7 g em água para completar 500 mL?",
    options: ["A) 0,1", "B) 0,2", "C) 0,4", "D) 0,5", "E) 1,0"],
    answer: "C",
    explanation:
      "$n = 11{,}7/58{,}5 = 0{,}2\\,mol$. $C = n/V = 0{,}2/0{,}5 = 0{,}4\\,mol/L$.",
  },
  {
    id: "qui-2020-01",
    year: 2020,
    subject: "quimica",
    number: 1,
    difficulty: "medio",
    topic: "Eletroquímica",
    statement:
      "Na eletrólise da água, o gás produzido no cátodo é:",
    options: [
      "A) Oxigênio",
      "B) Hidrogênio",
      "C) Cloro",
      "D) Ozônio",
      "E) Vapor d'água",
    ],
    answer: "B",
    explanation:
      "No cátodo ocorre redução: $2H_2O + 2e^- \\rightarrow H_2 + 2OH^-$. Portanto, produz-se hidrogênio ($H_2$).",
  },
  {
    id: "qui-2021-01",
    year: 2021,
    subject: "quimica",
    number: 1,
    difficulty: "dificil",
    topic: "Equilíbrio Químico",
    statement:
      "Para a reação $N_2(g) + 3H_2(g) \\rightleftharpoons 2NH_3(g)$, a constante de equilíbrio $K_c$ a uma dada temperatura é 1,5. Se $[N_2] = [H_2] = 1\\,M$, a reação está:",
    options: [
      "A) No equilíbrio",
      "B) Deslocada para a direita ($Q < K$)",
      "C) Deslocada para a esquerda ($Q > K$)",
      "D) Sem sentido definido",
      "E) Com $[NH_3] = 1{,}5\\,M$",
    ],
    answer: "B",
    explanation:
      "Considerando $[NH_3] = 0$, o quociente de reação $Q_c = 0 < K_c = 1{,}5$. Portanto a reação se desloca para a direita.",
  },
  {
    id: "qui-2022-01",
    year: 2022,
    subject: "quimica",
    number: 1,
    difficulty: "facil",
    topic: "Tabela Periódica",
    statement:
      "O elemento de número atômico 17 pertence ao grupo:",
    options: ["A) 1 (álcalis)", "B) 2 (alcalinos terrosos)", "C) 14", "D) 17 (halogênios)", "E) 18 (gases nobres)"],
    answer: "D",
    explanation:
      "O elemento de Z=17 é o Cloro (Cl), que possui configuração eletrônica [Ne]3s²3p⁵ — pertence ao grupo 17 (halogênios).",
  },
  {
    id: "qui-2023-01",
    year: 2023,
    subject: "quimica",
    number: 1,
    difficulty: "medio",
    topic: "Termoquímica",
    statement:
      "Em uma reação exotérmica, a variação de entalpia $\\Delta H$ é:",
    options: ["A) Zero", "B) Positiva", "C) Negativa", "D) Indefinida", "E) Igual à energia de ativação"],
    answer: "C",
    explanation:
      "Em reações exotérmicas, o sistema libera calor para a vizinhança. Por convenção, $\\Delta H < 0$ (negativo).",
  },
  {
    id: "qui-2024-01",
    year: 2024,
    subject: "quimica",
    number: 1,
    difficulty: "dificil",
    topic: "Cinética Química",
    statement:
      "A velocidade de uma reação de primeira ordem com constante $k = 0{,}02\\,s^{-1}$ quando $[A] = 0{,}5\\,M$ é:",
    options: ["A) $0{,}04\\,M/s$", "B) $0{,}01\\,M/s$", "C) $0{,}02\\,M/s$", "D) $0{,}25\\,M/s$", "E) $0{,}1\\,M/s$"],
    answer: "B",
    explanation:
      "$v = k[A] = 0{,}02 \\times 0{,}5 = 0{,}01\\,M/s$.",
  },
  {
    id: "qui-2025-01",
    year: 2025,
    subject: "quimica",
    number: 1,
    difficulty: "medio",
    topic: "Ácidos e Bases",
    statement:
      "O pH de uma solução de HCl com $[H^+] = 0{,}001\\,mol/L$ é:",
    options: ["A) 1", "B) 2", "C) 3", "D) 4", "E) 7"],
    answer: "C",
    explanation:
      "$pH = -\\log[H^+] = -\\log(10^{-3}) = 3$.",
  },

  // ===================== INGLÊS =====================
  {
    id: "ing-2019-01",
    year: 2019,
    subject: "ingles",
    number: 1,
    difficulty: "facil",
    topic: "Vocabulary / Grammar",
    statement:
      "Choose the alternative that correctly completes the sentence: 'She _____ to Paris three times since 2015.'",
    options: ["A) went", "B) has gone", "C) goes", "D) was going", "E) had gone"],
    answer: "B",
    explanation:
      "The present perfect ('has gone') is used for actions that happened at unspecified times in the past with relevance to the present. The expression 'since 2015' is a key indicator for present perfect tense.",
  },
  {
    id: "ing-2019-02",
    year: 2019,
    subject: "ingles",
    number: 2,
    difficulty: "medio",
    topic: "Reading Comprehension",
    statement:
      "Read the excerpt: 'Despite the government's efforts to reduce carbon emissions, scientists warn that global temperatures continue to rise at an alarming rate.' The word 'despite' indicates:",
    options: [
      "A) Cause and effect",
      "B) Contrast or concession",
      "C) Time sequence",
      "D) Addition of information",
      "E) Condition",
    ],
    answer: "B",
    explanation:
      "'Despite' is a preposition expressing contrast/concession — it introduces a fact that makes the main clause surprising or unexpected. It is synonymous with 'in spite of'.",
  },
  {
    id: "ing-2020-01",
    year: 2020,
    subject: "ingles",
    number: 1,
    difficulty: "medio",
    topic: "Grammar — Conditionals",
    statement:
      "Select the sentence in which the conditional is used correctly:",
    options: [
      "A) If I would have money, I will travel.",
      "B) If I have money, I would travel.",
      "C) If I had money, I would travel.",
      "D) If I had money, I will travel.",
      "E) If I would have money, I would travel.",
    ],
    answer: "C",
    explanation:
      "The second conditional (hypothetical present/future) uses: 'If + past simple, would + base verb'. Option C follows this pattern correctly.",
  },
  {
    id: "ing-2021-01",
    year: 2021,
    subject: "ingles",
    number: 1,
    difficulty: "dificil",
    topic: "Reading — Inference",
    statement:
      "The passage states: 'The algorithm's ability to detect patterns in vast datasets has revolutionized diagnostics, though ethical concerns about data privacy remain unresolved.' It can be inferred that:",
    options: [
      "A) The algorithm is unreliable for diagnostics.",
      "B) Ethical concerns have been fully addressed.",
      "C) AI in diagnostics brings both benefits and unresolved challenges.",
      "D) Data privacy is no longer a concern.",
      "E) The algorithm cannot detect patterns.",
    ],
    answer: "C",
    explanation:
      "The passage acknowledges the benefit ('revolutionized diagnostics') while noting 'ethical concerns remain unresolved' — a clear balance of benefit and challenge.",
  },
  {
    id: "ing-2022-01",
    year: 2022,
    subject: "ingles",
    number: 1,
    difficulty: "facil",
    topic: "Vocabulary",
    statement:
      "The word 'albeit' in 'The project succeeded, albeit slowly' is closest in meaning to:",
    options: [
      "A) therefore",
      "B) although",
      "C) because",
      "D) whenever",
      "E) unless",
    ],
    answer: "B",
    explanation:
      "'Albeit' is a formal conjunction meaning 'although' or 'even though'. It introduces a concessive clause.",
  },
  {
    id: "ing-2023-01",
    year: 2023,
    subject: "ingles",
    number: 1,
    difficulty: "medio",
    topic: "Grammar — Passive Voice",
    statement:
      "Transform to passive: 'Scientists discovered the new element in 2022.'",
    options: [
      "A) The new element was discovered by scientists in 2022.",
      "B) The new element is discovered by scientists in 2022.",
      "C) The new element was discover by scientists in 2022.",
      "D) Scientists were discovered the new element in 2022.",
      "E) The new element has been discovered in 2022.",
    ],
    answer: "A",
    explanation:
      "Passive voice formula: object + 'to be' (past) + past participle + 'by' + agent. 'discovered' → 'was discovered'. Option A is grammatically correct.",
  },
  {
    id: "ing-2024-01",
    year: 2024,
    subject: "ingles",
    number: 1,
    difficulty: "dificil",
    topic: "Reading — Critical Analysis",
    statement:
      "In the sentence 'The proliferation of misinformation underscores the need for critical media literacy', the word 'underscores' means:",
    options: [
      "A) undermines",
      "B) emphasizes",
      "C) questions",
      "D) eliminates",
      "E) confuses",
    ],
    answer: "B",
    explanation:
      "'Underscore' (verb) means to emphasize, highlight, or stress the importance of something — similar to 'underline' used figuratively.",
  },
  {
    id: "ing-2025-01",
    year: 2025,
    subject: "ingles",
    number: 1,
    difficulty: "medio",
    topic: "Grammar — Reported Speech",
    statement:
      "Convert to reported speech: She said, 'I am studying for the ITA exam.'",
    options: [
      "A) She said that she is studying for the ITA exam.",
      "B) She said that she was studying for the ITA exam.",
      "C) She said that she studied for the ITA exam.",
      "D) She told that she was studying for the ITA exam.",
      "E) She said she has been studying for the ITA exam.",
    ],
    answer: "B",
    explanation:
      "In reported speech, present continuous ('am studying') shifts back to past continuous ('was studying'). 'Said' does not take 'to' — 'told' does require 'to' (told me). Option B is correct.",
  },
];

export default questions;

export function getQuestionsByFilters(opts: {
  subjects?: Subject[];
  years?: number[];
  difficulties?: Difficulty[];
  limit?: number;
}): Question[] {
  let filtered = [...questions];
  if (opts.subjects?.length) filtered = filtered.filter((q) => opts.subjects!.includes(q.subject));
  if (opts.years?.length) filtered = filtered.filter((q) => opts.years!.includes(q.year));
  if (opts.difficulties?.length) filtered = filtered.filter((q) => opts.difficulties!.includes(q.difficulty));
  if (opts.limit) filtered = filtered.slice(0, opts.limit);
  return filtered;
}

export const SUBJECTS: { id: Subject; label: string; color: string; icon: string }[] = [
  { id: "matematica", label: "Matemática", color: "blue", icon: "∑" },
  { id: "fisica", label: "Física", color: "purple", icon: "⚛" },
  { id: "quimica", label: "Química", color: "green", icon: "⚗" },
  { id: "ingles", label: "Inglês", color: "amber", icon: "🇬🇧" },
];

export const YEARS = [2019, 2020, 2021, 2022, 2023, 2024, 2025];
