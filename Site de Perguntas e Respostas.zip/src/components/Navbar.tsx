import { Link, useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { BookOpen, BarChart2, LogOut, Beaker, ChevronRight } from 'lucide-react';

interface Props {
  userName?: string;
}

export default function Navbar({ userName }: Props) {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const links = [
    { to: '/dashboard', label: 'Início', icon: BookOpen },
    { to: '/study', label: 'Treinar', icon: ChevronRight },
    { to: '/simulation', label: 'Simulado', icon: Beaker },
    { to: '/performance', label: 'Desempenho', icon: BarChart2 },
  ];

  return (
    <nav className="sticky top-0 z-50 border-b border-[#1e2d50] bg-[#0a0f1e]/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link to="/dashboard" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-blue-600 flex items-center justify-center">
            <span className="text-white text-xs font-bold font-display">ITA</span>
          </div>
          <span className="font-display font-bold text-white text-sm tracking-wide hidden sm:block">
            ITA Study
          </span>
        </Link>

        <div className="flex items-center gap-1">
          {links.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className={`
                flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors
                ${location.pathname === to
                  ? 'bg-blue-600/20 text-blue-400'
                  : 'text-[#94a3b8] hover:text-white hover:bg-white/5'}
              `}
            >
              <Icon size={13} />
              <span className="hidden sm:block">{label}</span>
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {userName && (
            <span className="text-xs text-[#64748b] hidden md:block truncate max-w-[120px]">
              {userName}
            </span>
          )}
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs text-[#94a3b8] hover:text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut size={13} />
            <span className="hidden sm:block">Sair</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
