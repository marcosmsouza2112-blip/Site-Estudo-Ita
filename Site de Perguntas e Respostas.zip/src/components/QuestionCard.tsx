import { useState } from "react";
import type { Question } from "../data/questions";
import { getAIExplanation } from "../lib/api";

type Props = {
  question: Question;
  onAnswer: (answer: string, correct: boolean) => void;
  showIndex?: string;
  mode?: "treino" | "simulado";
};

const LABELS = ["A", "B", "C", "D", "E"];

const DIFFICULTY_COLORS: Record<string, string> = {
  facil: "#4ade80",
  medio: "#fbbf24",
  dificil: "#f87171",
};

const SUBJECT_LABELS: Record<string, string> = {
  matematica: "Matemática",
  fisica: "Física",
  quimica: "Química",
  ingles: "Inglês",
};

export default function QuestionCard({ question, onAnswer, showIndex, mode = "treino" }: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [loadingAI, setLoadingAI] = useState(false);

  async function handleConfirm() {
    if (!selected) return;
    setConfirmed(true);
    const correct = selected === question.answer;
    onAnswer(selected, correct);

    if (!correct && mode === "treino") {
      setLoadingAI(true);
      const exp = await getAIExplanation({
        question: question.statement,
        correctAnswer: question.answer,
        userAnswer: selected,
        subject: SUBJECT_LABELS[question.subject],
        topic: question.topic,
        explanation: question.explanation,
      });
      setAiExplanation(exp);
      setLoadingAI(false);
    }
  }

  const isCorrect = confirmed && selected === question.answer;
  const isWrong = confirmed && selected !== question.answer;

  return (
    <div className="max-w-2xl mx-auto">
      {/* Meta */}
      <div className="flex items-center gap-3 mb-5 text-xs opacity-40">
        {showIndex && <span>{showIndex}</span>}
        <span>ITA {question.year}</span>
        <span>·</span>
        <span>{SUBJECT_LABELS[question.subject]}</span>
        <span>·</span>
        <span>{question.topic}</span>
        <span className="ml-auto px-2 py-0.5 rounded-full text-xs font-bold" style={{
          background: `${DIFFICULTY_COLORS[question.difficulty]}20`,
          color: DIFFICULTY_COLORS[question.difficulty]
        }}>
          {question.difficulty}
        </span>
      </div>

      {/* Statement */}
      <div
        className="rounded-xl p-6 mb-5 leading-relaxed text-sm border border-white/8"
        style={{ background: "#0d0f1a" }}
      >
        <pre className="whitespace-pre-wrap font-mono text-sm" style={{ fontFamily: "inherit" }}>
          {question.statement}
        </pre>
      </div>

      {/* Options */}
      <div className="space-y-2 mb-5">
        {question.options.map((opt, i) => {
          const letter = LABELS[i];
          const isSelected = selected === letter;
          const isAnswer = question.answer === letter;

          let style: React.CSSProperties = {
            background: "#0d0f1a",
            border: "1px solid rgba(255,255,255,0.08)",
            cursor: confirmed ? "default" : "pointer",
          };

          if (confirmed) {
            if (isAnswer) style = { background: "rgba(74,222,128,0.1)", border: "1px solid rgba(74,222,128,0.4)", cursor: "default" };
            else if (isSelected && !isAnswer) style = { background: "rgba(248,113,113,0.1)", border: "1px solid rgba(248,113,113,0.4)", cursor: "default" };
          } else if (isSelected) {
            style = { background: "rgba(200,185,122,0.12)", border: "1px solid rgba(200,185,122,0.4)", cursor: "pointer" };
          }

          return (
            <button
              key={letter}
              disabled={confirmed}
              onClick={() => !confirmed && setSelected(letter)}
              className="w-full text-left rounded-xl px-4 py-3 flex items-start gap-3 transition-all text-sm"
              style={style}
            >
              <span
                className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                style={{
                  background: confirmed
                    ? isAnswer ? "#4ade80" : isSelected ? "#f87171" : "rgba(255,255,255,0.08)"
                    : isSelected ? "#c8b97a" : "rgba(255,255,255,0.08)",
                  color: confirmed
                    ? (isAnswer || isSelected) ? "#0a0c14" : "rgba(255,255,255,0.5)"
                    : isSelected ? "#0a0c14" : "rgba(255,255,255,0.5)",
                }}
              >
                {letter}
              </span>
              <span style={{ opacity: confirmed && !isAnswer && !isSelected ? 0.4 : 1 }}>
                {opt.replace(/^[A-E]\)\s*/, "")}
              </span>
            </button>
          );
        })}
      </div>

      {/* Confirm button */}
      {!confirmed && (
        <button
          disabled={!selected}
          onClick={handleConfirm}
          className="w-full py-3 rounded-xl font-bold tracking-wider text-sm uppercase transition-all disabled:opacity-20"
          style={{ background: selected ? "#c8b97a" : "rgba(200,185,122,0.2)", color: "#0a0c14" }}
        >
          Confirmar Resposta
        </button>
      )}

      {/* Feedback */}
      {confirmed && (
        <div
          className="rounded-xl p-5 mt-1"
          style={{
            background: isCorrect ? "rgba(74,222,128,0.08)" : "rgba(248,113,113,0.08)",
            border: `1px solid ${isCorrect ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.3)"}`,
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg">{isCorrect ? "✓" : "✗"}</span>
            <span className="font-bold text-sm" style={{ color: isCorrect ? "#4ade80" : "#f87171" }}>
              {isCorrect ? "Resposta Correta!" : `Errado — a correta era ${question.answer}`}
            </span>
          </div>

          {isWrong && (
            <>
              <div className="text-xs opacity-60 mb-3 leading-relaxed">
                <strong>Explicação:</strong> {question.explanation}
              </div>

              {loadingAI && (
                <div className="text-xs opacity-40 flex items-center gap-2">
                  <span className="animate-pulse">●</span> Gerando análise com IA...
                </div>
              )}

              {aiExplanation && (
                <div className="mt-3 pt-3 border-t border-white/8">
                  <div className="text-xs opacity-40 mb-2 tracking-widest uppercase">Correção Inteligente</div>
                  <div className="text-xs leading-relaxed opacity-70 whitespace-pre-wrap">{aiExplanation}</div>
                </div>
              )}
            </>
          )}

          {isCorrect && (
            <div className="text-xs opacity-50 leading-relaxed">{question.explanation}</div>
          )}
        </div>
      )}
    </div>
  );
}
