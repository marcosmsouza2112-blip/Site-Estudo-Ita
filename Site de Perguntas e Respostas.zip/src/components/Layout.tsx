import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import type { User } from "@supabase/supabase-js";

type Props = { children: React.ReactNode; user: User };

const NAV = [
  { path: "/dashboard", label: "Dashboard", icon: "⊞" },
  { path: "/treino", label: "Treino", icon: "✎" },
  { path: "/simulado", label: "Simulado", icon: "⏱" },
  { path: "/desempenho", label: "Desempenho", icon: "◈" },
];

export default function Layout({ children, user }: Props) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  async function handleLogout() {
    await supabase.auth.signOut();
    navigate("/login");
  }

  const name = user.user_metadata?.name || user.email?.split("@")[0] || "Aluno";

  return (
    <div className="min-h-screen flex" style={{ background: "#0a0c14", color: "#e8e6e0", fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}>
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-56 border-r border-white/8" style={{ background: "#0d0f1a" }}>
        {/* Logo */}
        <div className="px-5 py-6 border-b border-white/8">
          <div className="text-xs tracking-[0.3em] uppercase opacity-50 mb-1">Instituto</div>
          <div className="text-xl font-bold tracking-tight" style={{ color: "#c8b97a" }}>ITA Study</div>
          <div className="text-xs opacity-30 mt-0.5">1ª Fase · 2019–2025</div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.map((n) => {
            const active = pathname.startsWith(n.path);
            return (
              <Link
                key={n.path}
                to={n.path}
                className="flex items-center gap-3 px-3 py-2.5 rounded text-sm transition-all"
                style={active
                  ? { background: "rgba(200,185,122,0.12)", color: "#c8b97a", fontWeight: 600 }
                  : { color: "rgba(232,230,224,0.55)" }}
              >
                <span className="text-base w-5 text-center">{n.icon}</span>
                {n.label}
              </Link>
            );
          })}
        </nav>

        {/* User */}
        <div className="px-4 py-4 border-t border-white/8">
          <div className="text-xs opacity-40 mb-1 truncate">{user.email}</div>
          <div className="font-semibold text-sm truncate mb-3">{name}</div>
          <button
            onClick={handleLogout}
            className="text-xs px-3 py-1.5 rounded border border-white/10 opacity-50 hover:opacity-100 transition-opacity w-full text-left"
          >
            Sair →
          </button>
        </div>
      </aside>

      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-3 border-b border-white/8" style={{ background: "#0d0f1a" }}>
        <span className="text-base font-bold" style={{ color: "#c8b97a" }}>ITA Study</span>
        <button onClick={() => setMenuOpen(!menuOpen)} className="text-xl opacity-60">
          {menuOpen ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden fixed inset-0 z-40 pt-14" style={{ background: "#0d0f1a" }}>
          <nav className="px-4 py-4 space-y-1">
            {NAV.map((n) => (
              <Link
                key={n.path}
                to={n.path}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-3 px-3 py-3 rounded text-sm"
                style={pathname.startsWith(n.path)
                  ? { background: "rgba(200,185,122,0.12)", color: "#c8b97a" }
                  : { color: "rgba(232,230,224,0.7)" }}
              >
                <span>{n.icon}</span>{n.label}
              </Link>
            ))}
            <button onClick={handleLogout} className="text-sm opacity-40 px-3 py-2">Sair →</button>
          </nav>
        </div>
      )}

      {/* Main */}
      <main className="flex-1 md:pt-0 pt-14 overflow-auto">
        {children}
      </main>
    </div>
  );
}
