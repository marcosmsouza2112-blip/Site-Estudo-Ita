import { useEffect, useRef } from 'react';
import { Clock } from 'lucide-react';

interface Props {
  seconds: number;
  onTick: (s: number) => void;
  paused?: boolean;
  className?: string;
}

export default function Timer({ seconds, onTick, paused = false, className = '' }: Props) {
  const ref = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (paused) {
      if (ref.current) clearInterval(ref.current);
      return;
    }
    ref.current = setInterval(() => {
      onTick(seconds + 1);
    }, 1000);
    return () => { if (ref.current) clearInterval(ref.current); };
  }, [seconds, paused]);

  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;

  const fmt = (n: number) => String(n).padStart(2, '0');

  return (
    <div className={`flex items-center gap-1.5 font-mono text-sm ${className}`}>
      <Clock size={13} className="text-[#64748b]" />
      <span className="text-[#94a3b8]">
        {h > 0 ? `${fmt(h)}:` : ''}{fmt(m)}:{fmt(s)}
      </span>
    </div>
  );
}
