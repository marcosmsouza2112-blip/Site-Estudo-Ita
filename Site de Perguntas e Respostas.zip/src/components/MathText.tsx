import katex from 'katex';

interface Props {
  text: string;
  className?: string;
  block?: boolean;
}

export default function MathText({ text, className = '', block = false }: Props) {
  const rendered = renderMath(text);
  if (block) {
    return <div className={className} dangerouslySetInnerHTML={{ __html: rendered }} />;
  }
  return <span className={className} dangerouslySetInnerHTML={{ __html: rendered }} />;
}

function renderMath(text: string): string {
  // Replace $$...$$ (display math) first
  let result = text.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => {
    try {
      return katex.renderToString(math.trim(), { displayMode: true, throwOnError: false });
    } catch {
      return math;
    }
  });

  // Replace $...$ (inline math)
  result = result.replace(/\$([^$\n]+?)\$/g, (_, math) => {
    try {
      return katex.renderToString(math.trim(), { displayMode: false, throwOnError: false });
    } catch {
      return math;
    }
  });

  // Replace \n with <br> for line breaks
  result = result.replace(/\n/g, '<br>');

  // Bold text **...**
  result = result.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  return result;
}
